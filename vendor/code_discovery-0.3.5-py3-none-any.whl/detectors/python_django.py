"""Django REST Framework detector."""

from pathlib import Path
from typing import List

from detectors.base import BaseDetector
from core.models import FrameworkType


class DjangoRestFrameworkDetector(BaseDetector):
    """Detects Django projects that expose APIs via Django REST Framework."""

    def detect(self) -> bool:
        # DRF must be present (Django alone is not an API framework).
        if not (
            self._has_drf_dependency()
            or self._has_drf_imports()
        ):
            return False

        # And Django scaffolding (manage.py / settings.py / urls.py) must
        # exist; otherwise we are looking at a library that merely imports
        # rest_framework, not a Django service.
        return self._has_django_scaffolding()

    def get_framework_type(self) -> FrameworkType:
        return FrameworkType.DJANGO_REST_FRAMEWORK

    def get_source_paths(self) -> List[Path]:
        manage_files = self.find_files("manage.py", max_depth=4)
        roots: List[Path] = []
        seen_resolved: set = set()
        for manage in manage_files:
            parent = manage.parent
            rp = parent.resolve()
            if rp not in seen_resolved:
                seen_resolved.add(rp)
                roots.append(parent)
        repo = self.repo_path.resolve()
        # Monorepo layout: ``testproject/manage.py`` while the installable
        # package (e.g. ``djoser/``) sits next to ``testproject/`` at repo root.
        if roots and all(p.resolve() != repo for p in roots):
            if repo not in seen_resolved:
                roots.append(self.repo_path)
        if not roots:
            roots.append(self.repo_path)
        return roots

    # Excluded as path *segments* so names like ``intervenience/`` aren't dropped.
    _EXCLUDED_PATH_PARTS = frozenset({
        "venv", ".venv",
        "__pycache__", "site-packages", "node_modules",
    })

    def _has_drf_dependency(self) -> bool:
        # ``djangorestframework`` is the pip package; ``rest_framework`` is only an import name.
        for fname in (
            "requirements.txt",
            "requirements/base.txt",
            "requirements/production.txt",
            "requirements/dev.txt",
            "pyproject.toml",
            "Pipfile",
            "setup.py",
        ):
            if self.check_dependency(fname, "djangorestframework"):
                return True
        return False

    def _has_drf_imports(self) -> bool:
        py_files = [
            f for f in self.find_files("*.py", max_depth=12)
            if not self._EXCLUDED_PATH_PARTS.intersection(f.parts)
        ]
        for f in py_files[:80]:
            content = self.read_file(f)
            if not content:
                continue
            if "from rest_framework" in content or "import rest_framework" in content:
                return True
        return False

    def _has_django_scaffolding(self) -> bool:
        if self.find_files("manage.py", max_depth=4):
            return True
        # Service-style Django projects sometimes drop manage.py; settings.py
        # plus a urls.py with django imports is the next-best signal.
        settings_files = self.find_files("settings.py", max_depth=6)
        urls_files = self.find_files("urls.py", max_depth=6)
        if settings_files and urls_files:
            for u in urls_files[:20]:
                content = self.read_file(u)
                if content and ("django" in content or "urlpatterns" in content):
                    return True
        return False
