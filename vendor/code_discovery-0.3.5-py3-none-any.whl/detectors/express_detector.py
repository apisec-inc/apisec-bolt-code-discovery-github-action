"""Express.js framework detector."""

import json
from pathlib import Path
from typing import List, Optional
from detectors.base import BaseDetector
from core.models import FrameworkType

# Directories to exclude when scanning for Node.js source files.
# Shared with express_parser.py via the same constant name and values.
_EXCLUDE_DIRS = {"node_modules", "dist", "build", ".git", "coverage", ".nyc_output"}


def is_node_source_file(path: Path) -> bool:
    """Return False for generated, vendored, or test files in a Node.js project."""
    path_str = str(path)
    for excluded in _EXCLUDE_DIRS:
        if f"/{excluded}/" in path_str or f"\\{excluded}\\" in path_str:
            return False
    name = path.name
    if name.endswith(".min.js") or name.endswith(".min.ts"):
        return False
    if ".test." in name or ".spec." in name:
        return False
    return True


class ExpressDetector(BaseDetector):
    """Detector for Express.js applications."""

    def detect(self) -> bool:
        """Detect if Express.js is present in the repository."""
        indicators = [
            self._check_package_json(),
            self._check_express_imports(),
        ]
        return any(indicators)

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.EXPRESS

    def get_source_paths(self) -> List[Path]:
        """Get paths to JavaScript/TypeScript source files."""
        source_paths = []

        # Tier 1: Common Express route/source directory names
        common_dirs = [
            "routes",
            "src/routes",
            "server",
            "server/routes",
            "controllers",
            "src/controllers",
            "src",
            "app",
            "api",
            "src/api",
        ]
        for rel_dir in common_dirs:
            full_path = self.repo_path / rel_dir
            if full_path.exists() and full_path.is_dir():
                source_paths.append(full_path)

        # Tier 2: Root-level entry files (add their parent dir if not already included)
        root_entry_files = [
            "app.js", "app.ts",
            "server.js", "server.ts",
            "index.js", "index.ts",
        ]
        for entry_file in root_entry_files:
            full_path = self.repo_path / entry_file
            if full_path.exists() and self.repo_path not in source_paths:
                source_paths.append(self.repo_path)
                break

        # Tier 3: Fallback — scan for JS/TS files with express usage
        if not source_paths:
            js_ts_files = self._find_js_ts_files(max_depth=15)
            express_dirs: set = set()
            for f in js_ts_files[:50]:
                content = self.read_file(f)
                if content and self._has_express_reference(content):
                    express_dirs.add(f.parent)
            source_paths.extend(express_dirs)

        return source_paths

    # ------------------------------------------------------------------
    # Detection helpers
    # ------------------------------------------------------------------

    def _check_package_json(self) -> bool:
        """Check for express in package.json dependency files."""
        pkg_files = self.find_files("package.json", max_depth=10)
        for pkg_file in pkg_files:
            # Skip node_modules
            if "node_modules" in str(pkg_file):
                continue
            content = self.read_file(pkg_file)
            if not content:
                continue
            # Fast string check first
            if '"express"' not in content:
                continue
            # Then validate via JSON parse
            try:
                data = json.loads(content)
                deps = data.get("dependencies", {})
                dev_deps = data.get("devDependencies", {})
                if "express" in deps or "express" in dev_deps:
                    return True
            except (json.JSONDecodeError, AttributeError):
                # Fallback: trust the string check
                return True
        return False

    def _check_express_imports(self) -> bool:
        """Check for Express imports/requires in JS/TS source files."""
        js_ts_files = self._find_js_ts_files(max_depth=15)

        express_import_patterns = [
            "require('express')",
            'require("express")',
            "from 'express'",
            'from "express"',
            "import express",
        ]

        for js_file in js_ts_files[:50]:
            content = self.read_file(js_file)
            if content:
                for pattern in express_import_patterns:
                    if pattern in content:
                        return True
        return False

    # ------------------------------------------------------------------
    # BaseDetector overrides
    # ------------------------------------------------------------------

    def _get_build_file_patterns(self) -> List[str]:
        """Get build file patterns for Express/Node."""
        return ["package.json"]

    def _get_framework_indicators(self) -> List[str]:
        """Get framework indicators for Express."""
        return ['"express"']

    def _get_source_root_patterns(self) -> List[str]:
        """Get source root patterns for Express projects."""
        return ["src", "routes", "api", "controllers", "src/routes"]

    def _is_source_module(self, source_root: Path, module_info) -> bool:
        """Validate Express source module."""
        if not source_root.exists() or not source_root.is_dir():
            return False
        js_ts_files = list(source_root.rglob("*.js")) + list(source_root.rglob("*.ts")) + list(source_root.rglob("*.mjs"))
        if not js_ts_files:
            return False
        for f in js_ts_files[:10]:
            content = self.read_file(f)
            if content and self._has_express_reference(content):
                return True
        return False

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def _find_js_ts_files(self, max_depth: int = 15) -> List[Path]:
        """Find JavaScript and TypeScript source files, excluding non-source dirs."""
        results = []
        for pattern in ("*.js", "*.ts", "*.mjs"):
            for path in self.repo_path.rglob(pattern):
                if not self._is_source_file(path):
                    continue
                depth = len(path.relative_to(self.repo_path).parts)
                if depth <= max_depth:
                    results.append(path)
        return results

    def _is_source_file(self, path: Path) -> bool:
        """Return False for generated/vendored files."""
        return is_node_source_file(path)

    def _has_express_reference(self, content: str) -> bool:
        """Check if content references express."""
        return (
            "require('express')" in content
            or 'require("express")' in content
            or "from 'express'" in content
            or 'from "express"' in content
            or "express()" in content
            or "express.Router()" in content
        )

    def _is_likely_source_directory(self, directory: Path) -> bool:
        """Check if directory is likely a source directory with Express code."""
        js_ts_files = list(directory.rglob("*.js")) + list(directory.rglob("*.ts"))
        for f in js_ts_files[:5]:
            content = self.read_file(f)
            if content and self._has_express_reference(content):
                return True
        return False
