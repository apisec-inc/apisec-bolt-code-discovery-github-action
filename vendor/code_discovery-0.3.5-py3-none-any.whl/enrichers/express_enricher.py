"""Express.js endpoint enricher."""

import re
from pathlib import Path
from typing import List, Optional, Set
from enrichers.base import BaseEnricher
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    AuthenticationRequirement,
    AuthenticationType,
    FrameworkType,
    ParameterLocation,
)

# Auth middleware patterns commonly used with Express
_AUTH_MIDDLEWARE_PATTERNS = [
    r'passport\.authenticate\s*\(',
    r'\bverifyToken\b',
    r'\bauthenticate\b',
    r'\brequireAuth\b',
    r'\bisAuth\b',
    r'\bcheckAuth\b',
    r'\bauthMiddleware\b',
    r'\bisAuthenticated\b',
    r'\bjwtAuth\b',
    r'\bbearerAuth\b',
    r'\bverifyJWT\b',
    r'\bprotected\b',
    r'\bensureAuthenticated\b',
]
_AUTH_RE = re.compile("|".join(_AUTH_MIDDLEWARE_PATTERNS))

# Patterns that strongly suggest JWT/Bearer specifically
_JWT_INDICATORS = re.compile(
    r'jwt|bearer|verifyToken|verifyJWT|jwtAuth|bearerAuth',
    re.IGNORECASE,
)

# JSDoc @param tag: @param {Type} name - description
_JSDOC_PARAM_RE = re.compile(
    r'@param\s+\{(\w+)\}\s+(\w+)(?:\s+-\s*(.+))?'
)
# JSDoc @returns tag
_JSDOC_RETURNS_RE = re.compile(
    r'@returns?\s+(?:\{(\w+)\}\s+)?(.+)?'
)

# Response status codes from res.status(NNN).json(...) / res.status(NNN).send(...)
_STATUS_RE = re.compile(r'res\.status\s*\(\s*(\d{3})\s*\)')

# JSDoc block
_JSDOC_RE = re.compile(r'/\*\*([\s\S]*?)\*/', re.MULTILINE)

_JS_TYPE_MAP = {
    "string": "string",
    "number": "number",
    "integer": "integer",
    "boolean": "boolean",
    "object": "object",
    "array": "array",
    "any": "string",
}


class ExpressEnricher(BaseEnricher):
    """Enricher for Express.js endpoints."""

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.EXPRESS

    def enrich_endpoint(self, endpoint: APIEndpoint, content: str) -> APIEndpoint:
        """
        Enrich an Express endpoint by scanning the source file for:
        - Auth middleware on the matching route line
        - JSDoc @param tags near the route definition
        - res.status() calls scoped to the handler body
        """
        # Locate the handler body for this specific endpoint so that status
        # code and JSDoc enrichment are scoped — not polluted by other handlers
        # in the same file.
        handler_body = self._extract_handler_body_for_endpoint(endpoint, content)

        # 1. Detect auth middleware on the route registration line
        if not endpoint.authentication:
            endpoint = self._detect_auth_middleware(endpoint, content)

        # 2. Enhance parameter docs from JSDoc near this endpoint
        if endpoint.parameters:
            endpoint = self._enrich_params_from_jsdoc(endpoint, content)

        # 3. Discover response status codes scoped to the handler body
        if handler_body:
            endpoint = self._enrich_responses_from_status_calls(endpoint, handler_body)

        return endpoint

    # ------------------------------------------------------------------
    # Handler body extraction (scoped to the specific endpoint)
    # ------------------------------------------------------------------

    def _extract_handler_body_for_endpoint(
        self, endpoint: APIEndpoint, content: str
    ) -> Optional[str]:
        """
        Locate the route registration line that matches this endpoint's
        path and method, then extract the handler function body using brace
        counting.  Returns None if the route line cannot be found.
        """
        if not endpoint.path or not endpoint.method:
            return None

        # Build patterns for both OpenAPI and Express path formats
        express_path = re.sub(r'\{(\w+)\}', lambda m: ':' + m.group(1), endpoint.path)
        method_lower = endpoint.method.value.lower()

        quote_class = "['\"`]"
        for path_variant in (endpoint.path, express_path):
            escaped = re.escape(path_variant)
            pattern = r'(?:\w+)\.' + method_lower + r'\s*\(\s*' + quote_class + escaped + quote_class
            m = re.search(pattern, content, re.IGNORECASE)
            if m:
                return self._extract_brace_body(content, m.end())

        # Try chained: router.route('/path')...method(...)
        for path_variant in (endpoint.path, express_path):
            escaped = re.escape(path_variant)
            route_pattern = r'(?:\w+)\.route\s*\(\s*' + quote_class + escaped + quote_class
            m = re.search(route_pattern, content, re.IGNORECASE)
            if m:
                # Find the specific .method( after .route()
                after = content[m.end(): m.end() + 800]
                method_pattern = rf'\.{method_lower}\s*\('
                mm = re.search(method_pattern, after, re.IGNORECASE)
                if mm:
                    return self._extract_brace_body(content, m.end() + mm.end())

        return None

    def _extract_brace_body(self, content: str, start: int) -> str:
        """Extract the function body after start using brace counting."""
        # Scan forward to find the first opening brace
        max_scan = min(start + 5000, len(content))
        window = content[start:max_scan]
        brace_pos = window.find("{")
        if brace_pos == -1:
            return ""

        depth = 0
        i = brace_pos
        in_string = False
        string_char = ""

        while i < len(window):
            ch = window[i]
            if in_string:
                if ch == string_char and (i == 0 or window[i - 1] != "\\"):
                    in_string = False
            else:
                if ch in ('"', "'", "`"):
                    in_string = True
                    string_char = ch
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        return window[brace_pos + 1: i]
            i += 1

        return window[brace_pos + 1:]

    # ------------------------------------------------------------------
    # Auth middleware detection
    # ------------------------------------------------------------------

    def _detect_auth_middleware(
        self, endpoint: APIEndpoint, content: str
    ) -> APIEndpoint:
        """
        Look for the route registration line that matches this endpoint's
        path and method, then check whether any auth middleware appears
        between the path string and the final handler.
        """
        if not endpoint.path:
            return endpoint

        # Build a pattern that matches the route line for this endpoint
        express_path = re.sub(r'\{(\w+)\}', lambda m: ':' + m.group(1), endpoint.path)
        escaped_express = re.escape(express_path)

        method_lower = endpoint.method.value.lower()

        # Only try the Express-format path — source code will never have {id}
        quote_class = "['\"`]"
        pattern = (
            r'(?:app|router|api|\w+)\.' + method_lower + r'\s*\(\s*'
            + quote_class + escaped_express + quote_class + r'(.*?)(?:\)|\Z)'
        )
        m = re.search(pattern, content, re.DOTALL)
        if m and _AUTH_RE.search(m.group(1)):
            # Check if middleware name suggests JWT/Bearer specifically
            middleware_text = m.group(1)
            if _JWT_INDICATORS.search(middleware_text):
                auth_type = AuthenticationType.BEARER
                scheme = "bearer"
                bearer_format = "JWT"
            else:
                auth_type = AuthenticationType.CUSTOM
                scheme = None
                bearer_format = None

            endpoint.authentication = AuthenticationRequirement(
                type=auth_type,
                scheme=scheme,
                bearer_format=bearer_format,
                description="Authentication required (detected via middleware)",
            )

        return endpoint

    # ------------------------------------------------------------------
    # JSDoc parameter enrichment
    # ------------------------------------------------------------------

    def _enrich_params_from_jsdoc(
        self, endpoint: APIEndpoint, content: str
    ) -> APIEndpoint:
        """Update parameter types/descriptions from JSDoc @param tags near the endpoint."""
        param_by_name = {p.name: p for p in endpoint.parameters}
        if not param_by_name:
            return endpoint

        # Scope to the JSDoc comment nearest the route definition
        jsdoc_content = self._find_jsdoc_near_endpoint(endpoint, content)
        if not jsdoc_content:
            return endpoint

        for m in _JSDOC_PARAM_RE.finditer(jsdoc_content):
            js_type = m.group(1)
            param_name = m.group(2)
            description = m.group(3).strip() if m.group(3) else None

            if param_name in param_by_name:
                param = param_by_name[param_name]
                openapi_type = _JS_TYPE_MAP.get(js_type.lower(), "string")
                param.type = openapi_type
                if description and not param.description:
                    param.description = description

        return endpoint

    def _find_jsdoc_near_endpoint(
        self, endpoint: APIEndpoint, content: str
    ) -> Optional[str]:
        """Find the JSDoc block closest to this endpoint's route definition."""
        if not endpoint.path or not endpoint.method:
            return None

        express_path = re.sub(r'\{(\w+)\}', lambda m: ':' + m.group(1), endpoint.path)
        escaped = re.escape(express_path)
        method_lower = endpoint.method.value.lower()

        quote_class = "['\"`]"
        pattern = r'(?:\w+)\.' + method_lower + r'\s*\(\s*' + quote_class + escaped + quote_class
        m = re.search(pattern, content, re.IGNORECASE)
        if not m:
            return None

        # Look backward from the route line for the nearest JSDoc
        preceding = content[:m.start()]
        jsdoc_matches = list(_JSDOC_RE.finditer(preceding))
        if not jsdoc_matches:
            return None

        last_jsdoc = jsdoc_matches[-1]
        # Only use if nothing but whitespace separates it from the route
        between = preceding[last_jsdoc.end():].strip()
        if between and not re.match(r'^\s*$', between):
            return None

        return last_jsdoc.group(1)

    # ------------------------------------------------------------------
    # Response status code enrichment
    # ------------------------------------------------------------------

    def _enrich_responses_from_status_calls(
        self, endpoint: APIEndpoint, handler_body: str
    ) -> APIEndpoint:
        """Add APIResponse entries for each res.status(NNN) call in the handler body."""
        existing_codes: Set[int] = {r.status_code for r in endpoint.responses}
        new_codes: Set[int] = set()

        for m in _STATUS_RE.finditer(handler_body):
            try:
                code = int(m.group(1))
                if code not in existing_codes:
                    new_codes.add(code)
            except ValueError:
                pass

        for code in sorted(new_codes):
            endpoint.responses.append(
                APIResponse(
                    status_code=code,
                    description=self._status_description(code),
                )
            )

        return endpoint

    def _status_description(self, code: int) -> str:
        """Return a human-readable description for common HTTP status codes."""
        descriptions = {
            200: "OK",
            201: "Created",
            204: "No Content",
            400: "Bad Request",
            401: "Unauthorized",
            403: "Forbidden",
            404: "Not Found",
            409: "Conflict",
            422: "Unprocessable Entity",
            500: "Internal Server Error",
        }
        return descriptions.get(code, f"HTTP {code}")
