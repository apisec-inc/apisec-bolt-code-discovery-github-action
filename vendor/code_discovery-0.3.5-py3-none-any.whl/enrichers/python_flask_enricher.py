"""Flask endpoint enricher — fills request body schemas from dataclass-typed parameters."""

import ast
import re
from typing import Any, Dict, List, Optional

from enrichers.base import BaseEnricher
from core.models import APIEndpoint, FrameworkType, HTTPMethod

PYTHON_TYPE_MAP = {
    "int": "integer",
    "float": "number",
    "bool": "boolean",
    "str": "string",
    "dict": "object",
    "list": "array",
}


class FlaskEnricher(BaseEnricher):
    """Enricher for Flask endpoints."""

    def get_framework_type(self) -> FrameworkType:
        return FrameworkType.FLASK

    def enrich_endpoint(self, endpoint: APIEndpoint, content: str) -> APIEndpoint:
        if endpoint.method not in (HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH):
            return endpoint

        if endpoint.request_body and not self._is_generic_body(endpoint.request_body):
            return endpoint

        if not endpoint.operation_id:
            return endpoint

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return endpoint

        func = self._find_function(tree, endpoint.operation_id)
        if not func:
            return endpoint

        path_vars = set(re.findall(r"\{([^}]+)\}", endpoint.path))
        schema = self._find_dataclass_body_schema(func, path_vars, tree)
        if schema:
            endpoint.request_body = {
                "required": True,
                "content": {"application/json": {"schema": schema}},
            }

        return endpoint

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_generic_body(rb: Dict[str, Any]) -> bool:
        try:
            schema = rb.get("content", {}).get("application/json", {}).get("schema", {})
            return schema.get("type") == "object" and "properties" not in schema
        except (AttributeError, TypeError):
            return True

    @staticmethod
    def _find_function(tree: ast.AST, name: str) -> Optional[ast.FunctionDef]:
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == name:
                return node
        return None

    def _find_dataclass_body_schema(
        self, func: ast.FunctionDef, path_vars: set, tree: ast.AST
    ) -> Optional[Dict[str, Any]]:
        for arg in func.args.args:
            name = arg.arg
            if name in ("self", "cls") or name in path_vars:
                continue
            if not arg.annotation or not isinstance(arg.annotation, ast.Name):
                continue

            type_name = arg.annotation.id
            if type_name in PYTHON_TYPE_MAP:
                continue

            schema = self._find_dataclass_schema(tree, type_name)
            if schema and schema.get("properties"):
                return schema

        return None

    @staticmethod
    def _find_dataclass_schema(tree: ast.AST, class_name: str) -> Optional[Dict[str, Any]]:
        """Find a @dataclass class and extract its fields."""
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef) or node.name != class_name:
                continue
            is_dataclass = any(
                (isinstance(d, ast.Name) and d.id == "dataclass")
                or (isinstance(d, ast.Call) and isinstance(d.func, ast.Name) and d.func.id == "dataclass")
                for d in node.decorator_list
            )
            if not is_dataclass:
                continue

            properties: Dict[str, Any] = {}
            for item in node.body:
                if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                    field_name = item.target.id
                    properties[field_name] = FlaskEnricher._annotation_to_schema(item.annotation)
            if not properties:
                continue
            return {"type": "object", "properties": properties}

        return None

    @staticmethod
    def _annotation_to_schema(annotation: ast.AST) -> Dict[str, Any]:
        if isinstance(annotation, ast.Name):
            mapped = PYTHON_TYPE_MAP.get(annotation.id)
            if mapped:
                return {"type": mapped}
            return {"type": "object"}
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name):
            if annotation.value.id in ("List", "list"):
                return {"type": "array", "items": {"type": "object"}}
            if annotation.value.id in ("Dict", "dict"):
                return {"type": "object"}
            if annotation.value.id in ("Optional",):
                inner = annotation.slice
                return FlaskEnricher._annotation_to_schema(inner) if isinstance(inner, ast.Name) else {"type": "string"}
        return {"type": "string"}
