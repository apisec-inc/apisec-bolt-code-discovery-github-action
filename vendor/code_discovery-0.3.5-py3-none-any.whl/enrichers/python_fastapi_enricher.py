"""FastAPI endpoint enricher — fills request body schemas from Pydantic models."""

import ast
import re
from typing import Any, Dict, List, Optional, Union

from enrichers.base import BaseEnricher
from core.models import APIEndpoint, FrameworkType, HTTPMethod

FuncNode = Union[ast.FunctionDef, ast.AsyncFunctionDef]

PYTHON_TYPE_MAP = {
    "int": "integer",
    "float": "number",
    "bool": "boolean",
    "str": "string",
    "dict": "object",
    "list": "array",
    "bytes": "string",
}

SKIP_PARAM_TYPES = {"Request", "WebSocket", "BackgroundTasks", "Response", "Depends"}


class FastAPIEnricher(BaseEnricher):
    """Enricher for FastAPI endpoints."""

    def get_framework_type(self) -> FrameworkType:
        return FrameworkType.FASTAPI

    def enrich_endpoint(self, endpoint: APIEndpoint, content: str) -> APIEndpoint:
        if endpoint.method not in (HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH):
            return endpoint

        if endpoint.request_body and not self._is_generic_body(endpoint.request_body):
            return endpoint

        if not endpoint.operation_id or not endpoint.source_file:
            return endpoint

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return endpoint

        func = self._find_function(tree, endpoint.operation_id)
        if not func:
            return endpoint

        path_vars = set(re.findall(r"\{([^}]+)\}", endpoint.path))
        body = self._find_body_param_schema(func, path_vars, tree)
        if body:
            endpoint.request_body = {
                "required": True,
                "content": {"application/json": {"schema": body}},
            }

        return endpoint

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_generic_body(rb: Dict[str, Any]) -> bool:
        try:
            schema = rb.get("content", {}).get("application/json", {}).get("schema", {})
            return schema.get("type") == "object" and "properties" not in schema
        except (AttributeError, TypeError):
            return True

    @staticmethod
    def _find_function(tree: ast.AST, name: str) -> Optional[FuncNode]:
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
                return node
        return None

    def _find_body_param_schema(
        self, func: FuncNode, path_vars: set, tree: ast.AST
    ) -> Optional[Dict[str, Any]]:
        """Walk function params, return first Pydantic model schema found."""
        for arg in func.args.args:
            name = arg.arg
            if name in ("self", "cls") or name in path_vars:
                continue
            if not arg.annotation:
                continue

            type_name = self._annotation_type_name(arg.annotation)
            if not type_name:
                continue
            if type_name in SKIP_PARAM_TYPES or type_name in PYTHON_TYPE_MAP:
                continue

            schema = self._find_pydantic_schema(tree, type_name)
            if schema and schema.get("properties"):
                return schema

        return None

    @staticmethod
    def _annotation_type_name(node: ast.AST) -> Optional[str]:
        """Extract the simple type name from an annotation (unwraps Optional etc.)."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name):
            if node.value.id in ("Optional", "Annotated", "Union"):
                inner = node.slice
                if isinstance(inner, ast.Tuple) and inner.elts:
                    return FastAPIEnricher._annotation_type_name(inner.elts[0])
                return FastAPIEnricher._annotation_type_name(inner)
            if node.value.id in ("List", "list"):
                return "list"
        return None

    @staticmethod
    def _find_pydantic_schema(tree: ast.AST, class_name: str) -> Optional[Dict[str, Any]]:
        """Find a BaseModel class by name and extract its fields."""
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef) or node.name != class_name:
                continue
            if not any(
                (isinstance(b, ast.Name) and b.id == "BaseModel")
                or (isinstance(b, ast.Attribute) and b.attr == "BaseModel")
                for b in node.bases
            ):
                continue

            properties: Dict[str, Any] = {}
            required: List[str] = []
            for item in node.body:
                if not isinstance(item, ast.AnnAssign) or not isinstance(item.target, ast.Name):
                    continue
                field_name = item.target.id
                field_schema = FastAPIEnricher._annotation_to_schema(item.annotation)
                properties[field_name] = field_schema

                if item.value is None:
                    required.append(field_name)

            if not properties:
                continue
            schema: Dict[str, Any] = {"type": "object", "properties": properties}
            if required:
                schema["required"] = required
            return schema

        return None

    @staticmethod
    def _annotation_to_schema(annotation: ast.AST) -> Dict[str, Any]:
        if isinstance(annotation, ast.Name):
            mapped = PYTHON_TYPE_MAP.get(annotation.id)
            if mapped:
                return {"type": mapped}
            return {"type": "object"}
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name):
            outer = annotation.value.id
            if outer in ("Optional", "Union"):
                inner = annotation.slice
                if isinstance(inner, ast.Tuple) and inner.elts:
                    return FastAPIEnricher._annotation_to_schema(inner.elts[0])
                return FastAPIEnricher._annotation_to_schema(inner)
            if outer in ("List", "list"):
                inner = annotation.slice
                items = FastAPIEnricher._annotation_to_schema(inner) if isinstance(inner, ast.Name) else {"type": "object"}
                return {"type": "array", "items": items}
            if outer in ("Dict", "dict"):
                return {"type": "object"}
        return {"type": "string"}
