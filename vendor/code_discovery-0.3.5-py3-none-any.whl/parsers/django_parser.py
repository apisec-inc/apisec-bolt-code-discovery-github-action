"""Django REST Framework parser.

Resolves Django URL configurations and DRF view classes/functions into
``APIEndpoint`` records using ``ast`` only — no Django runtime is invoked,
so this works on any DRF source tree the user has on disk.

Pass overview:
    1. Index every ``.py`` file: imports, class defs, ``@api_view`` funcs,
       ``urlpatterns`` lists, and ``Router(...)`` registrations.
    2. Resolve each view class to its set of HTTP methods by walking the
       transitive base-class graph (DRF generics, mixins, plain ``APIView``).
    3. Walk URL trees, following ``include()`` to other files and recording
       ``(full_pattern, target)`` pairs. Router-backed includes expand into
       per-action route synthesis.
    4. Emit ``APIEndpoint`` records, normalizing the regex / path-converter
       syntax into OpenAPI ``{name}`` placeholders.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from core.models import (
    APIEndpoint,
    APIParameter,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)
from parsers.base import BaseParser


# ---------------------------------------------------------------------------
# DRF method/action tables
# ---------------------------------------------------------------------------

# Generic class-based views → HTTP methods they expose.
_DRF_GENERIC_METHODS: Dict[str, FrozenSet[str]] = {
    "ListAPIView": frozenset({"GET"}),
    "CreateAPIView": frozenset({"POST"}),
    "RetrieveAPIView": frozenset({"GET"}),
    "UpdateAPIView": frozenset({"PUT", "PATCH"}),
    "DestroyAPIView": frozenset({"DELETE"}),
    "ListCreateAPIView": frozenset({"GET", "POST"}),
    "RetrieveUpdateAPIView": frozenset({"GET", "PUT", "PATCH"}),
    "RetrieveDestroyAPIView": frozenset({"GET", "DELETE"}),
    "RetrieveUpdateDestroyAPIView": frozenset({"GET", "PUT", "PATCH", "DELETE"}),
}

# Plain APIView subclasses derive methods from their explicit ``def get/post/...``.
_HTTP_METHOD_FUNC_NAMES: FrozenSet[str] = frozenset({
    "get", "post", "put", "delete", "patch", "head", "options",
})

# DRF mixins → action names (router uses these).
_DRF_MIXIN_ACTIONS: Dict[str, FrozenSet[str]] = {
    "CreateModelMixin": frozenset({"create"}),
    "ListModelMixin": frozenset({"list"}),
    "RetrieveModelMixin": frozenset({"retrieve"}),
    "UpdateModelMixin": frozenset({"update", "partial_update"}),
    "DestroyModelMixin": frozenset({"destroy"}),
}

# ViewSet shorthands → built-in action sets.
_DRF_VIEWSET_ACTIONS: Dict[str, FrozenSet[str]] = {
    "ModelViewSet": frozenset({
        "list", "create", "retrieve", "update", "partial_update", "destroy",
    }),
    "ReadOnlyModelViewSet": frozenset({"list", "retrieve"}),
    # ``ViewSet`` and ``GenericViewSet`` are explicit — no implicit actions;
    # actions come from mixins or @action decorators.
    "ViewSet": frozenset(),
    "GenericViewSet": frozenset(),
}

# Action → (HTTP method, is_detail). Detail actions get the lookup segment.
_DRF_ROUTER_ACTION_MAP: Dict[str, Tuple[str, bool]] = {
    "list":           ("GET",    False),
    "create":         ("POST",   False),
    "retrieve":       ("GET",    True),
    "update":         ("PUT",    True),
    "partial_update": ("PATCH",  True),
    "destroy":        ("DELETE", True),
}

_KNOWN_ROUTER_CLASSES: FrozenSet[str] = frozenset({
    "DefaultRouter", "SimpleRouter",
})

# Django ``path()`` converters (``<int:id>``) → OpenAPI type.
_PATH_CONVERTER_TYPES: Dict[str, str] = {
    "int": "integer",
    "str": "string",
    "slug": "string",
    "uuid": "string",
    "path": "string",
}


# ---------------------------------------------------------------------------
# Internal data structures
# ---------------------------------------------------------------------------

@dataclass
class _ActionInfo:
    """A method decorated with ``@action(detail=..., methods=[...])``."""
    method_name: str
    detail: bool
    methods: List[str] = field(default_factory=list)
    url_path: Optional[str] = None  # defaults to method_name


@dataclass
class _ClassInfo:
    name: str
    qualname: str  # ``module.dotted.path.ClassName``
    file: Path
    bases: List[str]  # short names as written in source
    func_names: Set[str] = field(default_factory=set)  # all defined methods
    attributes: Dict[str, ast.expr] = field(default_factory=dict)
    actions: List[_ActionInfo] = field(default_factory=list)


@dataclass
class _ApiViewFunc:
    """A function decorated with ``@api_view([...])``."""
    name: str
    file: Path
    methods: List[str]


@dataclass
class _UrlEntry:
    """One entry inside a ``urlpatterns`` list.

    ``kind`` is one of: ``"include"``, ``"include_router"``,
    ``"include_local"``, ``"view"``.
    """
    kind: str
    pattern: str  # raw pattern as written (regex or path string)
    is_regex: bool
    target_module: Optional[str] = None       # for ``include('a.b.urls')``
    target_router_var: Optional[str] = None   # for ``include(router.urls)``
    target_local_var: Optional[str] = None    # for ``include(local_list_var)``
    view_class: Optional[str] = None          # for ``X.as_view()``
    view_func: Optional[str] = None           # for plain function or @api_view


@dataclass
class _UrlModule:
    file: Path
    module: str  # dotted module path (e.g. ``conduit.apps.articles.urls``)
    entries: List[_UrlEntry] = field(default_factory=list)


@dataclass
class _RouterRegistration:
    prefix: str
    viewset_name: str


@dataclass
class _Router:
    file: Path
    trailing_slash: bool = True
    registrations: List[_RouterRegistration] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class DjangoRestFrameworkParser(BaseParser):
    """Parses a Django REST Framework project tree into ``APIEndpoint`` records."""

    def __init__(self, source_paths: List[Path], repo_path: Path):
        super().__init__(source_paths, repo_path)

        # Pass 1 outputs.
        self._classes_by_qualname: Dict[str, _ClassInfo] = {}
        self._classes_by_name: Dict[str, List[_ClassInfo]] = {}
        self._api_view_funcs: Dict[Tuple[Path, str], _ApiViewFunc] = {}
        self._url_modules: Dict[str, _UrlModule] = {}  # keyed by dotted module path
        # Local list vars referenced via ``include(my_list)``, plus inline
        # list literals from ``include([...])`` / ``include(([...], 'ns'))``.
        self._local_url_lists: Dict[Tuple[Path, str], List[_UrlEntry]] = {}
        self._routers: Dict[Tuple[Path, str], _Router] = {}
        self._module_root: Optional[Path] = None
        # Memoized HTTP method sets per resolved class qualname.
        self._resolved_methods: Dict[str, Set[str]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_framework_type(self) -> FrameworkType:
        return FrameworkType.DJANGO_REST_FRAMEWORK

    def parse(self) -> DiscoveryResult:
        self._module_root = self._determine_module_root()
        py_files = [f for f in self.find_files("*.py") if self._is_source_file(f)]

        for f in py_files:
            self._index_file(f)

        endpoints = self._build_endpoints()

        return DiscoveryResult(
            framework=FrameworkType.DJANGO_REST_FRAMEWORK,
            endpoints=endpoints,
        )

    # ------------------------------------------------------------------
    # Pass 1 — file indexing
    # ------------------------------------------------------------------

    def _index_file(self, file_path: Path) -> None:
        content = self.read_file(file_path)
        if not content:
            return
        try:
            tree = ast.parse(content, filename=str(file_path))
        except SyntaxError:
            return

        module_path = self._module_path_for(file_path)

        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                self._record_class(node, module_path, file_path)
            elif isinstance(node, ast.FunctionDef):
                self._record_api_view_func(node, file_path)
            elif isinstance(node, ast.Assign):
                self._record_assignment(node, module_path, file_path)
            elif isinstance(node, ast.AugAssign):
                self._record_aug_assign(node, module_path, file_path)
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                # ``router.register(...)`` at module top-level.
                self._record_router_call(node.value, file_path)

    def _record_class(
        self, node: ast.ClassDef, module_path: str, file_path: Path
    ) -> None:
        bases = [self._base_name(b) for b in node.bases]
        bases = [b for b in bases if b]
        info = _ClassInfo(
            name=node.name,
            qualname=f"{module_path}.{node.name}" if module_path else node.name,
            file=file_path,
            bases=bases,
        )
        for child in node.body:
            if isinstance(child, ast.FunctionDef):
                info.func_names.add(child.name)
                action = self._extract_action_decorator(child)
                if action:
                    info.actions.append(action)
            elif isinstance(child, ast.Assign):
                for target in child.targets:
                    if isinstance(target, ast.Name):
                        info.attributes[target.id] = child.value

        self._classes_by_qualname[info.qualname] = info
        self._classes_by_name.setdefault(info.name, []).append(info)

    def _record_api_view_func(self, node: ast.FunctionDef, file_path: Path) -> None:
        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue
            if self._call_func_short_name(decorator) != "api_view":
                continue
            methods: List[str] = []
            if decorator.args:
                first = decorator.args[0]
                methods = self._extract_string_list(first)
            self._api_view_funcs[(file_path, node.name)] = _ApiViewFunc(
                name=node.name,
                file=file_path,
                methods=[m.upper() for m in methods] or ["GET"],
            )
            return

    def _record_assignment(
        self, node: ast.Assign, module_path: str, file_path: Path
    ) -> None:
        # ``urlpatterns = [...]`` (also ``[...] + extra(...)`` / ``a + b``).
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "urlpatterns":
                val = node.value
                elements = self._collect_url_pattern_elements(val)
                if elements is not None:
                    self._record_urlpatterns_from_elements(
                        elements, module_path, file_path
                    )
                elif (
                    isinstance(val, ast.Attribute)
                    and val.attr == "urls"
                    and isinstance(val.value, ast.Name)
                ):
                    # ``urlpatterns = router.urls`` (common in small url modules).
                    mod = _UrlModule(file=file_path, module=module_path)
                    mod.entries.append(
                        _UrlEntry(
                            kind="include_router",
                            pattern="",
                            is_regex=False,
                            target_router_var=val.value.id,
                        )
                    )
                    self._url_modules[module_path] = mod
                return

        # Local list variable that may be referenced via ``include(var)``.
        if (
            len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, (ast.List, ast.Tuple))
        ):
            var_name = node.targets[0].id
            if var_name != "urlpatterns":
                entries: List[_UrlEntry] = []
                for elt in node.value.elts:
                    entry = self._parse_url_entry(elt, file_path)
                    if entry is not None:
                        entries.append(entry)
                if entries:
                    self._local_url_lists[(file_path, var_name)] = entries

        # ``router = DefaultRouter(...)`` → start a router.
        if (
            len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, ast.Call)
            and self._call_func_short_name(node.value) in _KNOWN_ROUTER_CLASSES
        ):
            trailing = True
            for kw in node.value.keywords:
                if kw.arg == "trailing_slash" and isinstance(kw.value, ast.Constant):
                    trailing = bool(kw.value.value)
            self._routers[(file_path, node.targets[0].id)] = _Router(
                file=file_path,
                trailing_slash=trailing,
            )

    def _record_aug_assign(
        self, node: ast.AugAssign, module_path: str, file_path: Path
    ) -> None:
        """``urlpatterns += [...]`` — append to an existing url module."""
        if not isinstance(node.target, ast.Name) or node.target.id != "urlpatterns":
            return
        if not isinstance(node.op, ast.Add):
            return
        elements = self._collect_url_pattern_elements(node.value)
        if elements is None:
            return
        self._append_urlpattern_elements(elements, module_path, file_path)

    def _append_urlpattern_elements(
        self, elements: List[ast.expr], module_path: str, file_path: Path
    ) -> None:
        existing = self._url_modules.get(module_path)
        if existing is None:
            self._record_urlpatterns_from_elements(elements, module_path, file_path)
            return
        for elt in elements:
            entry = self._parse_url_entry(elt, file_path)
            if entry is not None:
                existing.entries.append(entry)

    def _record_router_call(self, call: ast.Call, file_path: Path) -> None:
        """Record ``router.register('prefix', ViewSet)`` against the named router."""
        if not isinstance(call.func, ast.Attribute) or call.func.attr != "register":
            return
        if not isinstance(call.func.value, ast.Name) or len(call.args) < 2:
            return
        router = self._routers.get((file_path, call.func.value.id))
        if router is None:
            return
        prefix = self._extract_string_constant(call.args[0])
        viewset = self._name_of(call.args[1])
        if prefix is None or viewset is None:
            return
        router.registrations.append(
            _RouterRegistration(prefix=prefix, viewset_name=viewset)
        )

    def _record_urlpatterns_from_elements(
        self, elements: List[ast.expr], module_path: str, file_path: Path
    ) -> None:
        url_module = _UrlModule(file=file_path, module=module_path)
        for elt in elements:
            entry = self._parse_url_entry(elt, file_path)
            if entry is not None:
                url_module.entries.append(entry)
        self._url_modules[module_path] = url_module

    def _collect_url_pattern_elements(
        self, node: ast.expr
    ) -> Optional[List[ast.expr]]:
        """Flatten the RHS of ``urlpatterns =`` into url-entry expressions.

        Supports list/tuple literals, ``+`` chains (``static``, ``… +
        i18n_patterns(...)``), and ``i18n_patterns(path(...), ...)``.
        """
        if isinstance(node, (ast.List, ast.Tuple)):
            return list(node.elts)
        if isinstance(node, ast.Call):
            if self._call_func_short_name(node) == "i18n_patterns":
                out: List[ast.expr] = []
                for arg in node.args:
                    if isinstance(arg, ast.Call):
                        out.append(arg)
                    elif isinstance(arg, (ast.List, ast.Tuple)):
                        for elt in arg.elts:
                            if isinstance(elt, ast.Call):
                                out.append(elt)
                return out
            return None  # e.g. ``static(...)`` — not expanded here
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self._collect_url_pattern_elements(node.left) or []
            right = self._collect_url_pattern_elements(node.right) or []
            return left + right
        return None

    def _parse_url_entry(
        self, node: ast.AST, file_path: Path
    ) -> Optional[_UrlEntry]:
        if not isinstance(node, ast.Call):
            return None
        func_name = self._call_func_short_name(node)
        if func_name not in {"path", "re_path", "url"}:
            return None
        if len(node.args) < 2:
            return None

        pattern_node, target_node = node.args[0], node.args[1]
        pattern = self._extract_string_constant(pattern_node)
        if pattern is None:
            return None
        is_regex = func_name in {"re_path", "url"}

        # ``include(...)``
        if (
            isinstance(target_node, ast.Call)
            and self._call_func_short_name(target_node) == "include"
            and target_node.args
        ):
            inc_arg = target_node.args[0]

            # ``include((first, 'namespace'))`` — Django's namespacing form;
            # the first element carries the actual urlpatterns reference.
            if isinstance(inc_arg, ast.Tuple) and inc_arg.elts:
                inc_arg = inc_arg.elts[0]

            mod_str = self._extract_string_constant(inc_arg)
            if mod_str is not None:
                return _UrlEntry(
                    kind="include",
                    pattern=pattern,
                    is_regex=is_regex,
                    target_module=mod_str,
                )
            # ``include(router.urls)`` — Attribute access over a router var.
            if (
                isinstance(inc_arg, ast.Attribute)
                and inc_arg.attr == "urls"
                and isinstance(inc_arg.value, ast.Name)
            ):
                return _UrlEntry(
                    kind="include_router",
                    pattern=pattern,
                    is_regex=is_regex,
                    target_router_var=inc_arg.value.id,
                )
            # ``include(local_list_var)`` — list defined in same file.
            if isinstance(inc_arg, ast.Name):
                return _UrlEntry(
                    kind="include_local",
                    pattern=pattern,
                    is_regex=is_regex,
                    target_local_var=inc_arg.id,
                )
            # ``include([url(...), ...])`` — inline list literal. Stash under
            # a synthetic key; ``id(inc_arg)`` is unique per AST node within
            # this parse and is only ever combined with ``file_path``.
            if isinstance(inc_arg, (ast.List, ast.Tuple)):
                inline_entries: List[_UrlEntry] = []
                for elt in inc_arg.elts:
                    sub = self._parse_url_entry(elt, file_path)
                    if sub is not None:
                        inline_entries.append(sub)
                key = f"__inline_{id(inc_arg)}"
                self._local_url_lists[(file_path, key)] = inline_entries
                return _UrlEntry(
                    kind="include_local",
                    pattern=pattern,
                    is_regex=is_regex,
                    target_local_var=key,
                )
            return None

        # ``BlogList.as_view()`` or ``views.BlogList.as_view()``.
        if isinstance(target_node, ast.Call):
            cls = self._as_view_class_name(target_node)
            if cls:
                return _UrlEntry(
                    kind="view",
                    pattern=pattern,
                    is_regex=is_regex,
                    view_class=cls,
                )

        # Plain function reference (``views.home`` / ``my_func``).
        view_name = self._name_of(target_node)
        if view_name:
            return _UrlEntry(
                kind="view",
                pattern=pattern,
                is_regex=is_regex,
                view_func=view_name,
            )

        return None

    # ------------------------------------------------------------------
    # Pass 2 helpers — class method resolution
    # ------------------------------------------------------------------

    def _resolve_class_methods(
        self, class_name: str, near: Optional[Path] = None
    ) -> Set[str]:
        """HTTP methods exposed by a class-based view (``near`` disambiguates same-name classes)."""
        infos = self._candidate_classes(class_name, near)
        methods: Set[str] = set()
        for info in infos:
            methods |= self._resolve_methods_for(info, set())
        return methods

    def _resolve_methods_for(
        self, info: _ClassInfo, seen: Set[str]
    ) -> Set[str]:
        if info.qualname in self._resolved_methods:
            return self._resolved_methods[info.qualname]
        if info.qualname in seen:
            return set()
        seen.add(info.qualname)

        methods: Set[str] = set()
        for name in info.func_names:
            if name in _HTTP_METHOD_FUNC_NAMES:
                methods.add(name.upper())

        for base in info.bases:
            if base in _DRF_GENERIC_METHODS:
                methods |= _DRF_GENERIC_METHODS[base]
                continue
            if base == "APIView":
                continue
            for parent in self._classes_by_name.get(base, []):
                methods |= self._resolve_methods_for(parent, seen)

        self._resolved_methods[info.qualname] = methods
        return methods

    def _resolve_viewset_actions(
        self, class_name: str, near: Optional[Path] = None
    ) -> Set[str]:
        """Viewset action names (built-in CRUD + ``@action`` decorators) for router expansion."""
        infos = self._candidate_classes(class_name, near)
        actions: Set[str] = set()
        for info in infos:
            actions |= self._resolve_actions_for(info, set())
        return actions

    def _resolve_actions_for(
        self, info: _ClassInfo, seen: Set[str]
    ) -> Set[str]:
        if info.qualname in seen:
            return set()
        seen.add(info.qualname)

        actions: Set[str] = set()
        for child in info.actions:
            actions.add(child.method_name)
        # DRF's DefaultRouter binds CRUD actions via ``hasattr(viewset, name)``
        # at runtime, so a user-defined ``def update(self, ...)`` on a plain
        # ``GenericViewSet`` exposes ``PUT`` even without ``UpdateModelMixin``.
        for crud in _DRF_ROUTER_ACTION_MAP:
            if crud in info.func_names:
                actions.add(crud)

        for base in info.bases:
            if base in _DRF_VIEWSET_ACTIONS:
                actions |= _DRF_VIEWSET_ACTIONS[base]
                continue
            if base in _DRF_MIXIN_ACTIONS:
                actions |= _DRF_MIXIN_ACTIONS[base]
                continue
            for parent in self._classes_by_name.get(base, []):
                actions |= self._resolve_actions_for(parent, seen)

        return actions

    def _resolve_lookup_kwarg(
        self, class_name: str, near: Optional[Path] = None
    ) -> str:
        """Return the URL kwarg name a router uses for the detail segment.

        DRF precedence: ``lookup_url_kwarg`` > ``lookup_field`` > ``"pk"``.
        """
        lookup_field = "pk"
        lookup_kwarg: Optional[str] = None
        for info in self._candidate_classes(class_name, near):
            if "lookup_field" in info.attributes:
                val = self._extract_string_constant(info.attributes["lookup_field"])
                if val:
                    lookup_field = val
            if "lookup_url_kwarg" in info.attributes:
                val = self._extract_string_constant(info.attributes["lookup_url_kwarg"])
                if val:
                    lookup_kwarg = val
        return lookup_kwarg or lookup_field

    # ------------------------------------------------------------------
    # Pass 3 + 4 — URL tree expansion + endpoint emission
    # ------------------------------------------------------------------

    def _build_endpoints(self) -> List[APIEndpoint]:
        roots = self._find_root_url_modules()
        endpoints: List[APIEndpoint] = []
        seen: Set[Tuple[str, str]] = set()

        for root in roots:
            self._expand(root, prefix="", endpoints=endpoints, seen=seen, depth=0)

        return endpoints

    def _find_root_url_modules(self) -> List[_UrlModule]:
        """Identify URL modules to use as expansion entry points.

        A module is a root iff no other module (or local sub-list) reaches
        it via ``include(...)``. Includes hidden inside local list vars
        (e.g. ``login_urlpatterns = [...]``) and inline list literals are
        walked too, otherwise leaf urls.py files appear as additional
        roots and get emitted without their parent prefix.
        """
        included: Set[str] = set()

        def collect(entries: List[_UrlEntry]) -> None:
            for entry in entries:
                if entry.kind == "include" and entry.target_module:
                    included.add(entry.target_module)

        for module in self._url_modules.values():
            collect(module.entries)
        for entries in self._local_url_lists.values():
            collect(entries)

        # Match by both fully-qualified and suffix names since some projects
        # are scanned from a path that yields a different prefix than the
        # importer expected (single-app sandboxes, namespace packages).
        included_suffixes = {f".{m}" for m in included}
        roots = [
            m for name, m in self._url_modules.items()
            if name not in included
            and not any(name.endswith(suf) for suf in included_suffixes)
        ]
        roots.sort(key=lambda m: str(m.file).lower())
        return roots

    def _expand(
        self,
        url_module: _UrlModule,
        prefix: str,
        endpoints: List[APIEndpoint],
        seen: Set[Tuple[str, str]],
        depth: int,
    ) -> None:
        if depth > 12:
            return  # cycle guard

        for entry in url_module.entries:
            combined = self._combine_patterns(prefix, entry.pattern, entry.is_regex)

            if entry.kind == "include" and entry.target_module:
                child = (
                    self._url_modules.get(entry.target_module)
                    or self._lookup_relative_module(entry.target_module)
                )
                if child is not None:
                    self._expand(child, combined, endpoints, seen, depth + 1)
                continue

            if entry.kind == "include_router" and entry.target_router_var:
                router = self._routers.get(
                    (url_module.file, entry.target_router_var)
                )
                if router is not None:
                    self._expand_router(router, combined, endpoints, seen)
                continue

            if entry.kind == "include_local" and entry.target_local_var:
                local = self._local_url_lists.get(
                    (url_module.file, entry.target_local_var)
                )
                if local is not None:
                    synthetic = _UrlModule(
                        file=url_module.file,
                        module=url_module.module,
                        entries=local,
                    )
                    self._expand(synthetic, combined, endpoints, seen, depth + 1)
                continue

            if entry.kind == "view":
                self._emit_view_endpoints(entry, combined, url_module.file, endpoints, seen)

    def _expand_router(
        self,
        router: _Router,
        prefix: str,
        endpoints: List[APIEndpoint],
        seen: Set[Tuple[str, str]],
    ) -> None:
        for reg in router.registrations:
            list_path = self._join_path_segment(prefix, reg.prefix)
            actions = self._resolve_viewset_actions(reg.viewset_name, near=router.file)
            if not actions:
                continue

            lookup_kwarg = self._resolve_lookup_kwarg(reg.viewset_name, near=router.file)
            detail_path = self._join_path_segment(list_path, f"<{lookup_kwarg}>")

            for action in actions:
                # Built-in CRUD action.
                spec = _DRF_ROUTER_ACTION_MAP.get(action)
                if spec:
                    method, is_detail = spec
                    raw = detail_path if is_detail else list_path
                    self._emit_endpoint(
                        raw_path=raw,
                        method=method,
                        source_file=router.file,
                        endpoints=endpoints,
                        seen=seen,
                        trailing_slash=router.trailing_slash,
                        view_class=reg.viewset_name,
                        operation_hint=f"{reg.viewset_name}.{action}",
                    )
                    continue
                # Custom @action method.
                act = self._find_action(reg.viewset_name, action, near=router.file)
                if act is None:
                    continue
                base = detail_path if act.detail else list_path
                action_segment = act.url_path or act.method_name
                raw = self._join_path_segment(base, action_segment)
                for http_method in act.methods or ["GET"]:
                    self._emit_endpoint(
                        raw_path=raw,
                        method=http_method.upper(),
                        source_file=router.file,
                        endpoints=endpoints,
                        seen=seen,
                        trailing_slash=router.trailing_slash,
                        view_class=reg.viewset_name,
                        operation_hint=f"{reg.viewset_name}.{act.method_name}",
                    )

    def _emit_view_endpoints(
        self,
        entry: _UrlEntry,
        full_pattern: str,
        source_file: Path,
        endpoints: List[APIEndpoint],
        seen: Set[Tuple[str, str]],
    ) -> None:
        if entry.view_class:
            methods = self._resolve_class_methods(entry.view_class, near=source_file)
            for m in sorted(methods):
                self._emit_endpoint(
                    raw_path=full_pattern,
                    method=m,
                    source_file=(
                        self._source_file_for_class(entry.view_class, near=source_file)
                        or source_file
                    ),
                    endpoints=endpoints,
                    seen=seen,
                    view_class=entry.view_class,
                )
            return

        if entry.view_func:
            short = entry.view_func.split(".")[-1]
            # Prefer same-app definitions; fall back globally if none match.
            candidates = [f for f in self._api_view_funcs.values() if f.name == short]
            same_pkg = [f for f in candidates if f.file.parent == source_file.parent]
            for func in (same_pkg or candidates):
                for m in func.methods:
                    self._emit_endpoint(
                        raw_path=full_pattern,
                        method=m.upper(),
                        source_file=func.file,
                        endpoints=endpoints,
                        seen=seen,
                        view_func=func.name,
                    )

    def _emit_endpoint(
        self,
        raw_path: str,
        method: str,
        source_file: Path,
        endpoints: List[APIEndpoint],
        seen: Set[Tuple[str, str]],
        trailing_slash: bool = True,
        view_class: Optional[str] = None,
        view_func: Optional[str] = None,
        operation_hint: Optional[str] = None,
    ) -> None:
        normalized, params = self._normalize_pattern(raw_path)
        if not trailing_slash and normalized.endswith("/") and len(normalized) > 1:
            normalized = normalized.rstrip("/")

        # Drop patterns we couldn't reduce to a concrete URL (e.g. ``v(?:1|2)/``).
        if self._has_unresolved_regex(normalized):
            return

        key = (normalized, method)
        if key in seen:
            return
        seen.add(key)

        try:
            http_method = HTTPMethod(method)
        except ValueError:
            return

        operation_id = operation_hint or view_class or view_func
        endpoints.append(
            APIEndpoint(
                path=normalized,
                method=http_method,
                operation_id=operation_id,
                parameters=params,
                source_file=self.get_relative_path(source_file),
            )
        )

    # ------------------------------------------------------------------
    # Pattern combination & normalization
    # ------------------------------------------------------------------

    def _combine_patterns(self, prefix: str, child: str, child_is_regex: bool) -> str:
        """Concatenate parent/child URL patterns.

        Drops the child's leading ``^`` so an empty regex anchor like
        ``include(router.urls)`` (pattern ``r'^'``) doesn't leak through
        and produce paths like ``^api/^articles``.
        """
        if child_is_regex and child.startswith("^"):
            child = child[1:]
        return prefix + child

    def _join_path_segment(self, prefix: str, segment: str) -> str:
        """Append a path-style segment, ensuring a single ``/`` boundary."""
        if prefix and not prefix.rstrip("$").endswith("/"):
            prefix = prefix + "/"
        return prefix + segment

    def _normalize_pattern(
        self, raw: str
    ) -> Tuple[str, List[APIParameter]]:
        """Convert a Django URL pattern to OpenAPI form and extract path params.

        Handles: regex anchors, ``(?P<name>...)`` named groups,
        ``<int:id>`` path converters, ``/?`` optional trailing slash.
        """
        s = raw

        params: List[APIParameter] = []
        seen_names: Set[str] = set()

        def add_param(name: str, type_hint: str = "string") -> None:
            if name in seen_names:
                return
            seen_names.add(name)
            params.append(
                APIParameter(
                    name=name,
                    location=ParameterLocation.PATH,
                    required=True,
                    type=type_hint,
                )
            )

        # Order matters: process ``(?P<name>regex)`` BEFORE bare ``<name>`` so
        # the inner ``<name>`` is not consumed by the path-converter rule.
        def named_group_repl(m: re.Match) -> str:
            name = m.group(1)
            inner = m.group(2)
            type_hint = "integer" if re.fullmatch(
                r"\\d[+*]?|\[\\d\][+*]?|\[0-9\][+*]?", inner
            ) else "string"
            add_param(name, type_hint)
            return "{" + name + "}"

        s = re.sub(r"\(\?P<(\w+)>([^)]*)\)", named_group_repl, s)

        def converter_repl(m: re.Match) -> str:
            converter, name = m.group(1), m.group(2)
            add_param(name, _PATH_CONVERTER_TYPES.get(converter, "string"))
            return "{" + name + "}"

        s = re.sub(r"<(\w+):(\w+)>", converter_repl, s)

        def bare_repl(m: re.Match) -> str:
            name = m.group(1)
            add_param(name)
            return "{" + name + "}"

        s = re.sub(r"<(\w+)>", bare_repl, s)

        # ``(?:foo)`` → ``foo``; alternation/nesting is left for the caller
        # to reject via ``_has_unresolved_regex``.
        s = re.sub(r"\(\?:([^()|]*)\)", r"\1", s)

        # Strip regex anchors and optional-trailing-slash artifacts.
        s = s.replace("^", "")
        s = re.sub(r"/\?\$?$", "", s)
        s = s.rstrip("$").rstrip("/")
        # Collapse accidental double slashes from chained includes.
        s = re.sub(r"/{2,}", "/", s)
        if not s.startswith("/"):
            s = "/" + s
        return s, params

    @staticmethod
    def _has_unresolved_regex(path: str) -> bool:
        """True if a normalized path still contains regex metacharacters."""
        return any(ch in path for ch in "()|")

    # ------------------------------------------------------------------
    # Misc helpers
    # ------------------------------------------------------------------

    def _determine_module_root(self) -> Path:
        for sp in self.source_paths:
            if sp.is_dir():
                return sp
            if sp.is_file():
                return sp.parent
        return self.repo_path

    def _module_path_for(self, file_path: Path) -> str:
        try:
            rel = file_path.relative_to(self._module_root or self.repo_path)
        except ValueError:
            try:
                rel = file_path.relative_to(self.repo_path)
            except ValueError:
                return file_path.stem
        parts = list(rel.with_suffix("").parts)
        return ".".join(parts)

    def _is_source_file(self, path: Path) -> bool:
        s = str(path)
        bad = (
            f"{path.anchor}venv",
            "/venv/", "\\venv\\",
            "/.venv/", "\\.venv\\",
            "/__pycache__/", "\\__pycache__\\",
            "/site-packages/", "\\site-packages\\",
            "/migrations/", "\\migrations\\",
            "/node_modules/", "\\node_modules\\",
        )
        return not any(token in s for token in bad)

    def _lookup_relative_module(self, target: str) -> Optional[_UrlModule]:
        """Suffix-match ``include('foo.bar')`` against indexed dotted paths.

        Tolerates source-root mismatches that shorten or lengthen the
        importer-side module string (single-app sandboxes, namespace pkgs).
        """
        if not target:
            return None
        for name, module in self._url_modules.items():
            if name == target or name.endswith("." + target):
                return module
        return None

    def _source_file_for_class(
        self, class_name: str, near: Optional[Path] = None
    ) -> Optional[Path]:
        infos = self._candidate_classes(class_name, near)
        return infos[0].file if infos else None

    def _find_action(
        self,
        class_name: str,
        action_name: str,
        near: Optional[Path] = None,
    ) -> Optional[_ActionInfo]:
        for info in self._candidate_classes(class_name, near):
            for act in info.actions:
                if act.method_name == action_name:
                    return act
        return None

    def _candidate_classes(
        self, class_name: str, near: Optional[Path]
    ) -> List[_ClassInfo]:
        """Prefer classes in ``near``'s package; fall back to all definitions."""
        infos = self._classes_by_name.get(class_name, [])
        if not infos or near is None:
            return infos
        same_pkg = [i for i in infos if i.file.parent == near.parent]
        return same_pkg or infos

    # ----- AST helpers -----

    @staticmethod
    def _base_name(node: ast.expr) -> Optional[str]:
        """Return the short class name for a base expression.

        ``Foo`` → ``"Foo"``, ``mixins.Foo`` → ``"Foo"``,
        ``a.b.Foo`` → ``"Foo"``. Anything else → ``None``.
        """
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    @staticmethod
    def _as_view_class_name(call: ast.Call) -> Optional[str]:
        """Short class name from ``…as_view()`` (``Foo`` or ``views.Foo``)."""
        if not (
            isinstance(call.func, ast.Attribute)
            and call.func.attr == "as_view"
        ):
            return None
        v = call.func.value
        if isinstance(v, ast.Name):
            return v.id
        if isinstance(v, ast.Attribute):
            return v.attr
        return None

    @staticmethod
    def _call_func_short_name(call: ast.Call) -> Optional[str]:
        if isinstance(call.func, ast.Name):
            return call.func.id
        if isinstance(call.func, ast.Attribute):
            return call.func.attr
        return None

    @staticmethod
    def _extract_string_constant(node: ast.AST) -> Optional[str]:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None

    @staticmethod
    def _extract_string_list(node: ast.AST) -> List[str]:
        out: List[str] = []
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            for elt in node.elts:
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                    out.append(elt.value)
        return out

    @staticmethod
    def _name_of(node: ast.AST) -> Optional[str]:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    def _extract_action_decorator(
        self, func: ast.FunctionDef
    ) -> Optional[_ActionInfo]:
        for dec in func.decorator_list:
            call = dec if isinstance(dec, ast.Call) else None
            if call is None:
                continue
            if self._call_func_short_name(call) != "action":
                continue
            detail = False
            methods: List[str] = []
            url_path: Optional[str] = None
            for kw in call.keywords:
                if kw.arg == "detail" and isinstance(kw.value, ast.Constant):
                    detail = bool(kw.value.value)
                elif kw.arg == "methods":
                    methods = self._extract_string_list(kw.value)
                elif kw.arg == "url_path":
                    url_path = self._extract_string_constant(kw.value)
            return _ActionInfo(
                method_name=func.name,
                detail=detail,
                methods=methods,
                url_path=url_path,
            )
        return None
