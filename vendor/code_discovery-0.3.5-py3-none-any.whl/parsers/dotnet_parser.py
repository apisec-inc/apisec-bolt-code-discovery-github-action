"""ASP.NET Core parser."""

import re
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple
from parsers.base import BaseParser
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


class DotNetParser(BaseParser):
    """Parser for ASP.NET Core APIs."""

    SIMPLE_TYPES = {
        "string",
        "String",
        "int",
        "Int32",
        "long",
        "Int64",
        "float",
        "Float",
        "double",
        "Double",
        "decimal",
        "Decimal",
        "bool",
        "Boolean",
        "Guid",
        "DateTime",
        "DateOnly",
        "TimeOnly",
    }

    SERVICE_TYPES = {
        "ILogger",
        "ILoggerFactory",
        "IServiceProvider",
        "CancellationToken",
        "ISender",
        "IMediator",
        "IMapper",
        "HttpContext",
        "HttpRequest",
        "HttpResponse",
        "IHttpClientFactory",
        "IOptions",
        "IConfiguration",
    }

    # OpenApiInfo.Title values that ship with `dotnet new webapi` /
    # `dotnet new minimal-api` scaffolding. Treating these as no-title-set
    # lets info.title fall through to the repository basename, matching the
    # FastAPI/Flask behavior where the customer hasn't named their service.
    BOILERPLATE_TITLES = {
        "ASP.NET Core API",
        "ASP.NET Core Web API",
        "My API",
        "WebApplication1",
        "WebApi",
    }

    _ACTION_TOKEN = "[action]"
    _ASYNC_SUFFIX = "Async"

    # Method declaration: one or more access/qualifier keywords, a return type,
    # the method name (optionally generic), then an opening parenthesis.
    # Constructors (no return type), properties (no `(`), and indexers
    # (`this[`) do not satisfy this shape and are skipped naturally.
    _METHOD_DECL_RE = re.compile(
        r'^[ \t]*'
        r'(?:(?:public|private|protected|internal|static|virtual|override'
        r'|sealed|abstract|async|new|partial|extern)\s+)+'
        r'(?:[\w<>\[\],\s\.\?]+?\s+)'
        r'(?P<name>\w+)\s*'
        r'(?:<[^<>]+>)?\s*'
        r'\(',
        re.MULTILINE,
    )

    # The trailing lookahead requires `,` or `]` so the regex matches both the
    # standalone form (``[HttpGet]``) and the combined-attribute form
    # (``[HttpGet, Authorize]``) while ignoring incidental matches inside
    # attribute strings such as ``[Description("Use HttpPost")]``.
    _HTTP_VERB_ATTR_RE = re.compile(
        r'\bHttp(?P<verb>Get|Post|Put|Delete|Patch|Head|Options)\b'
        r'(?:\s*\((?P<args>[^)]*)\))?'
        r'\s*(?=[,\]])'
    )

    # No leading ``[`` so ``[HttpPost, Route("/x")]`` is also matched.
    _ROUTE_ATTR_RE = re.compile(r'\bRoute\s*\(\s*"(?P<path>[^"]*)"\s*\)')

    def __init__(self, source_paths: List[Path], repo_path: Path):
        super().__init__(source_paths, repo_path)
        self._type_schema_cache: Dict[str, Dict[str, Any]] = {}
        self._file_content_cache: Dict[Path, str] = {}

    def parse(self) -> DiscoveryResult:
        """Parse ASP.NET Core source files for API endpoints."""
        endpoints: List[APIEndpoint] = []
        cs_files = self.find_files("*.cs")

        # First pass: cache all file contents for cross-file type resolution
        for cs_file in cs_files:
            content = self.read_file(cs_file)
            if content:
                self._file_content_cache[cs_file] = content

        # Second pass: parse endpoints (now with full type cache available)
        for cs_file in cs_files:
            content = self._file_content_cache.get(cs_file)
            if not content:
                continue

            if self._is_api_controller(content):
                endpoints.extend(self._parse_controller(cs_file, content))

            if self._is_carter_module(content):
                endpoints.extend(self._parse_carter_module(cs_file, content))

        return DiscoveryResult(
            framework=FrameworkType.ASPNET_CORE,
            endpoints=endpoints,
            title=self._extract_app_title(),
        )

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.ASPNET_CORE

    def _extract_app_title(self) -> Optional[str]:
        """OpenAPI title from OpenApiInfo { Title = ... } (Swashbuckle / NSwag patterns).

        Returns None when the matched title is a known scaffold default so
        info.title falls through to the repo name in OpenAPIGenerator.
        """
        pattern = re.compile(
            r"new\s+OpenApiInfo\s*(?:\(\s*\))?\s*\{.*?Title\s*=\s*\"([^\"]+)\"",
            re.DOTALL,
        )
        for content in self._file_content_cache.values():
            m = pattern.search(content)
            if m:
                title = m.group(1).strip()
                if title in self.BOILERPLATE_TITLES:
                    return None
                return title
        return None

    def _is_api_controller(self, content: str) -> bool:
        """Check if the class is an API controller (ASP.NET Core or ASP.NET MVC Framework)."""
        if "[ApiController]" in content or ": ControllerBase" in content:
            return True

        if self._is_ardalis_endpoint(content):
            return True

        # ASP.NET MVC Framework patterns
        # Check for inheritance from Controller (not ControllerBase)
        if re.search(r':\s*Controller\b', content):
            # Also check if it has HTTP method attributes or Route attributes
            if any(pattern in content for pattern in [
                "[HttpGet", "[HttpPost", "[HttpPut", "[HttpDelete", "[HttpPatch",
                "[Route(", "[ActionName(",
            ]):
                return True
        
        # Check for System.Web.Mvc namespace (ASP.NET MVC Framework)
        if "System.Web.Mvc" in content and ": Controller" in content:
            return True
        
        return False

    def _parse_controller(self, file_path: Path, content: str) -> List[APIEndpoint]:
        """Parse a controller file for endpoints."""
        endpoints = []
        
        # Extract class-level [Route] attribute
        class_route = self._extract_class_route(content)
        
        # Find all HTTP method attributes
        methods = self._extract_methods(content)
        
        for method_info in methods:
            endpoint = self._create_endpoint(
                method_info,
                class_route,
                file_path,
                content,
            )
            if endpoint:
                endpoints.append(endpoint)

        return endpoints

    def _extract_class_route(self, content: str) -> str:
        """Extract class-level [Route] attribute (ASP.NET Core and MVC Framework)."""
        # Find the class declaration first
        class_match = re.search(r'class\s+(\w+)Controller', content)
        if not class_match:
            return ""
        
        class_start = class_match.start()
        # Find the opening brace of the class
        class_brace = content.find('{', class_start)
        if class_brace == -1:
            return ""
        
        # Only search for route attributes before the class opening brace
        class_declaration = content[:class_brace]
        
        # Match [Route("path")] or [Route("api/[controller]")] before class
        patterns = [
            (r'\[Route\s*\(\s*"([^"]+)"\s*\)\]', 1),
            (r'\[RoutePrefix\s*\(\s*"([^"]+)"\s*\)\]', 1),  # ASP.NET MVC Framework
        ]
        
        for pattern, group_num in patterns:
            # Search in reverse to get the last match before the class
            matches = list(re.finditer(pattern, class_declaration))
            if matches:
                # Get the last match (closest to the class declaration)
                match = matches[-1]
                route = match.group(group_num)
                # Handle [controller] placeholder
                if '[controller]' in route:
                    controller_name = class_match.group(1).lower()
                    route = route.replace('[controller]', controller_name)
                return route
        
        # For ASP.NET MVC Framework, if no explicit route, use convention-based routing
        # Check if this is MVC Framework (has System.Web.Mvc)
        if "System.Web.Mvc" in content:
            controller_name = class_match.group(1).lower()
            # Convention: /ControllerName (without "Controller" suffix)
            return controller_name
        
        return ""

    def _extract_methods(self, content: str) -> List[Dict[str, Any]]:
        """Extract endpoint methods, scoping each method's attribute block precisely.

        Method-first scoping: locate every method declaration, then collect the
        ``[...]`` attributes that belong to *that* method (the contiguous run
        immediately preceding the declaration, separated only by whitespace and
        comments). This prevents a ``[Route(...)]`` placed before one method
        from being forward-matched onto a sibling, which is the bug behind
        GET/POST swaps.
        """
        methods: List[Dict[str, Any]] = []
        attribute_spans = self._scan_attribute_spans(content)

        for decl in self._METHOD_DECL_RE.finditer(content):
            method_start = decl.start()
            paren_open = decl.end() - 1
            signature = self._capture_signature(content, method_start, paren_open)

            attrs_block = self._collect_method_attributes(
                content, method_start, attribute_spans
            )
            if not attrs_block:
                continue

            verb_attrs = self._extract_verb_attributes(attrs_block)
            if not verb_attrs:
                continue

            method_route = self._extract_method_route(attrs_block)

            for http_method, verb_path in verb_attrs:
                if verb_path is not None:
                    path = verb_path
                elif method_route is not None:
                    path = method_route
                else:
                    path = ""

                methods.append({
                    "path": path,
                    "method": http_method,
                    "signature": signature,
                    "position": method_start,
                })

        # MVC Framework convention-based routing: when no actions carry HTTP
        # attributes, public action methods are exposed as GETs keyed by name.
        if "System.Web.Mvc" in content and not methods:
            public_method_pattern = (
                r'public\s+(?:async\s+)?'
                r'(?:ActionResult|JsonResult|ViewResult|ContentResult|RedirectResult'
                r'|HttpStatusCodeResult|object|string|int|void)\s+'
                r'(\w+)\s*\('
            )
            for match in re.finditer(public_method_pattern, content):
                mvc_name = match.group(1)
                if mvc_name in {'GetType', 'ToString', 'Equals', 'GetHashCode', 'Dispose'}:
                    continue
                methods.append({
                    "path": mvc_name,
                    "method": HTTPMethod.GET,
                    "signature": match.group(0),
                    "position": match.start(),
                })

        return methods

    @staticmethod
    def _capture_signature(content: str, start: int, paren_open: int) -> str:
        """Return method text from ``start`` through the matching ``)``.

        Falls back to a bounded slice if the parameter list is malformed so the
        caller still receives non-empty input for downstream regexes.
        """
        if paren_open >= len(content) or content[paren_open] != '(':
            return content[start:start + 200]
        depth = 0
        for i in range(paren_open, len(content)):
            ch = content[i]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    return content[start:i + 1]
        return content[start:start + 500]

    @classmethod
    def _scan_attribute_spans(cls, content: str) -> List[Tuple[int, int]]:
        """Return ``(start, end_inclusive)`` of every top-level ``[...]`` block.

        Strings, character literals, and comments are skipped so brackets that
        appear inside them are never mistaken for attributes. Array type
        markers (``int[]``) and indexers (``arr[0]``) may also be returned;
        they are filtered out by the contiguous-run rule in
        :meth:`_collect_method_attributes`.
        """
        spans: List[Tuple[int, int]] = []
        i, n = 0, len(content)
        while i < n:
            ch = content[i]
            if ch == '"':
                i = cls._skip_string(content, i, '"')
            elif ch == "'":
                i = cls._skip_string(content, i, "'")
            elif ch == '/' and i + 1 < n and content[i + 1] == '/':
                end = content.find('\n', i)
                i = n if end == -1 else end + 1
            elif ch == '/' and i + 1 < n and content[i + 1] == '*':
                end = content.find('*/', i + 2)
                i = n if end == -1 else end + 2
            elif ch == '[':
                close = cls._find_attribute_close(content, i)
                if close == -1:
                    i += 1
                else:
                    spans.append((i, close))
                    i = close + 1
            else:
                i += 1
        return spans

    @classmethod
    def _collect_method_attributes(
        cls,
        content: str,
        method_start: int,
        attribute_spans: List[Tuple[int, int]],
    ) -> str:
        """Return ``[...]`` attributes that immediately precede the method.

        Walks ``attribute_spans`` from right to left and accepts each span only
        if everything between it and the cursor is whitespace or comments. The
        first span that fails that test ends the run -- so attributes inside an
        earlier method's body, or array/indexer ``[]`` brackets in the same
        scope, cannot leak into the wrong method.
        """
        attributes: List[Tuple[int, int]] = []
        cursor = method_start
        for start, end in reversed(attribute_spans):
            if end >= cursor:
                continue
            gap = content[end + 1:cursor]
            if not cls._is_whitespace_or_comment(gap):
                break
            attributes.append((start, end))
            cursor = start
        attributes.reverse()
        return "\n".join(content[s:e + 1] for s, e in attributes)

    @staticmethod
    def _skip_string(text: str, start: int, quote: str) -> int:
        """Return the index just past the string literal that begins at ``start``."""
        n = len(text)
        i = start + 1
        while i < n and text[i] != quote:
            if text[i] == '\\' and i + 1 < n:
                i += 2
                continue
            i += 1
        return i + 1

    @classmethod
    def _find_attribute_close(cls, text: str, open_pos: int) -> int:
        """Return the index of the ``]`` that closes the attribute opened at ``open_pos``.

        Tracks bracket depth while skipping string literals so a ``]`` embedded
        in an attribute argument cannot terminate the attribute early.
        """
        depth = 0
        i, n = open_pos, len(text)
        while i < n:
            ch = text[i]
            if ch == '"':
                i = cls._skip_string(text, i, '"')
                continue
            if ch == '[':
                depth += 1
            elif ch == ']':
                depth -= 1
                if depth == 0:
                    return i
            i += 1
        return -1

    @staticmethod
    def _is_whitespace_or_comment(text: str) -> bool:
        """True if ``text`` is only whitespace, comments, or preprocessor directives.

        Preprocessor lines (``#region``, ``#endregion``, ``#if``, ``#endif``,
        ``#pragma``, ``#nullable``, ...) are treated as ignorable so that
        attributes wrapped in conditional compilation still attach to the
        method that follows them.
        """
        i, n = 0, len(text)
        while i < n:
            ch = text[i]
            if ch.isspace():
                i += 1
            elif ch == '/' and i + 1 < n and text[i + 1] == '/':
                end = text.find('\n', i)
                i = n if end == -1 else end + 1
            elif ch == '/' and i + 1 < n and text[i + 1] == '*':
                end = text.find('*/', i + 2)
                if end == -1:
                    return False
                i = end + 2
            elif ch == '#':
                end = text.find('\n', i)
                i = n if end == -1 else end + 1
            else:
                return False
        return True

    @classmethod
    def _extract_verb_attributes(
        cls, attrs_block: str
    ) -> List[Tuple[HTTPMethod, Optional[str]]]:
        """Return ``[Http<Verb>(...)]`` attributes paired with their inline path."""
        results: List[Tuple[HTTPMethod, Optional[str]]] = []
        for m in cls._HTTP_VERB_ATTR_RE.finditer(attrs_block):
            http_method = getattr(HTTPMethod, m.group("verb").upper(), None)
            if http_method is None:
                continue
            results.append((http_method, cls._extract_first_string_arg(m.group("args"))))
        return results

    @staticmethod
    def _extract_first_string_arg(args: Optional[str]) -> Optional[str]:
        """Return the path template -- the first positional string argument.

        ASP.NET HTTP attributes place the route template first by convention
        (``[HttpGet("/items/{id}", Name = "X")]``). Forms that lead with a
        named argument before the path are vanishingly rare and intentionally
        not handled here.
        """
        if args is None:
            return None
        m = re.match(r'\s*"([^"]*)"', args)
        return m.group(1) if m else None

    @classmethod
    def _extract_method_route(cls, attrs_block: str) -> Optional[str]:
        """Return the method-level ``[Route("...")]`` template, if present.

        If multiple ``[Route]`` attributes are stacked the last one wins; C#
        treats stacked Routes as parallel mappings, but Code Bolt emits a
        single endpoint per method.
        """
        matches = list(cls._ROUTE_ATTR_RE.finditer(attrs_block))
        return matches[-1].group("path") if matches else None

    def _extract_method_name(self, signature: str) -> str:
        """Extract method name from signature."""
        match = re.search(r'\s+(\w+)\s*\(', signature)
        if match:
            return match.group(1)
        return ""

    def _create_endpoint(
        self,
        method_info: Dict[str, Any],
        class_route: str,
        file_path: Path,
        file_content: str,
    ) -> Optional[APIEndpoint]:
        """Create an APIEndpoint from method information."""
        # Skip when no explicit route is declared: ASP.NET falls back to
        # convention-based routing which we cannot reconstruct statically.
        if not class_route and not method_info.get("path"):
            return None

        full_path = self._combine_paths(class_route, method_info["path"])
        full_path = self._resolve_action_token(full_path, method_info.get("signature", ""))
        full_path = self.normalize_path(full_path)
        
        # Extract parameters from signature
        parameters = self._extract_parameters(method_info["signature"], full_path)
        
        # Extract request body (only for methods that support it)
        request_body = None
        if method_info["method"] not in {HTTPMethod.GET, HTTPMethod.HEAD, HTTPMethod.OPTIONS, HTTPMethod.DELETE}:
            request_body = self._extract_request_body(method_info["signature"], file_content)
        
        # Extract response schema
        response_schema = self._extract_response_schema(method_info["signature"], file_content)
        
        # Create endpoint
        endpoint = APIEndpoint(
            path=full_path,
            method=method_info["method"],
            operation_id=self._generate_operation_id(full_path, method_info["method"]),
            parameters=parameters,
            request_body=request_body,
            responses=[
                APIResponse(
                    status_code=200,
                    description="Successful response",
                    schema=response_schema,
                )
            ],
            source_file=self.get_relative_path(file_path),
            source_line=self._calculate_line_number(file_content, method_info.get("position", 0)),
        )
        
        return endpoint

    _CARTER_MAP_TOKENS = ("MapGet(", "MapPost(", "MapPut(", "MapDelete(", "MapPatch(")
    _ARDALIS_BASE_TYPES = ("EndpointBaseAsync", "EndpointBaseSync", "BaseAsyncEndpoint")

    def _is_carter_module(self, content: str) -> bool:
        """Detect Carter modules and minimal-API classes registering routes via ``app.MapVerb(...)``."""
        if "ICarterModule" in content:
            return True
        return any(token in content for token in self._CARTER_MAP_TOKENS)

    @classmethod
    def _is_ardalis_endpoint(cls, content: str) -> bool:
        """Detect Ardalis.ApiEndpoints classes (HandleAsync override decorated with ``[HttpVerb(...)]``)."""
        return any(marker in content for marker in cls._ARDALIS_BASE_TYPES)

    def _parse_carter_module(self, file_path: Path, content: str) -> List[APIEndpoint]:
        """Parse Carter minimal APIs (and general Map* routes)."""
        endpoints: List[APIEndpoint] = []

        for route in self._extract_carter_routes(content):
            normalized_path = self.normalize_path(route["path"])
            parameters = self._create_path_parameters(normalized_path)
            extra_params, request_body = self._classify_lambda_parameters(
                route.get("lambda_params", []),
                normalized_path,
                content,
                parameters,
            )
            parameters.extend(extra_params)

            responses = route.get("responses") or [
                APIResponse(
                    status_code=200,
                    description="Successful response",
                )
            ]

            # GET, HEAD, and OPTIONS methods should not have requestBody
            final_request_body = None
            if route["method"] not in {HTTPMethod.GET, HTTPMethod.HEAD, HTTPMethod.OPTIONS}:
                final_request_body = request_body

            endpoint = APIEndpoint(
                path=normalized_path,
                method=route["method"],
                summary=route.get("summary"),
                description=route.get("description"),
                operation_id=route.get("operation_id")
                or self._generate_operation_id(normalized_path, route["method"]),
                parameters=parameters,
                request_body=final_request_body,
                responses=responses,
                source_file=self.get_relative_path(file_path),
                source_line=route.get("line"),
            )

            endpoints.append(endpoint)

        return endpoints

    def _extract_carter_routes(self, content: str) -> List[Dict[str, Any]]:
        """Extract app.Map* route definitions from Carter modules."""
        routes: List[Dict[str, Any]] = []
        pattern = re.compile(r'app\.Map(?P<verb>Get|Post|Put|Delete|Patch)\s*\(', re.MULTILINE)

        for match in pattern.finditer(content):
            verb = match.group("verb").upper()
            http_method = getattr(HTTPMethod, verb, None)
            if not http_method:
                continue

            path, _ = self._extract_carter_path(content, match.end())
            if not path:
                continue

            block = self._extract_expression_block(content, match.start())
            metadata = self._extract_carter_metadata(block, content)
            line_number = self._calculate_line_number(content, match.start())
            lambda_params = self._extract_lambda_parameters(block)

            routes.append(
                {
                    "path": path,
                    "method": http_method,
                    "summary": metadata.get("summary"),
                    "description": metadata.get("description"),
                    "operation_id": metadata.get("operation_id"),
                    "line": line_number,
                    "lambda_params": lambda_params,
                    "responses": metadata.get("responses"),
                }
            )

        return routes

    def _extract_carter_path(self, content: str, start_index: int) -> Tuple[str, int]:
        """Extract the first argument (route path) from app.Map* call."""
        idx = start_index
        n = len(content)

        while idx < n and content[idx].isspace():
            idx += 1

        prefix = ""
        while idx < n and content[idx] in ('@', '$'):
            prefix += content[idx]
            idx += 1

        if idx >= n or content[idx] != '"':
            # Not a literal path (could be constant) – skip for now
            return "", idx

        idx += 1
        path_chars = []
        verbatim = "@" in prefix

        while idx < n:
            char = content[idx]

            if char == '"':
                if verbatim:
                    if idx + 1 < n and content[idx + 1] == '"':
                        path_chars.append('"')
                        idx += 2
                        continue
                    else:
                        break
                else:
                    if idx > 0 and content[idx - 1] == "\\":
                        path_chars.append(char)
                        idx += 1
                        continue
                    else:
                        break

            path_chars.append(char)
            idx += 1

        return "".join(path_chars).strip(), idx

    def _extract_expression_block(self, content: str, start_index: int) -> str:
        """Extract the entire route expression up to the terminating semicolon."""
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0
        in_string = False
        string_char = ""
        i = start_index
        n = len(content)

        while i < n:
            char = content[i]

            if in_string:
                if char == "\\" and string_char == '"' and (i + 1) < n:
                    i += 2
                    continue
                if char == string_char:
                    in_string = False
                    string_char = ""
                i += 1
                continue

            if char in ('"', "'"):
                in_string = True
                string_char = char
            elif char == '(':
                paren_depth += 1
            elif char == ')':
                paren_depth = max(0, paren_depth - 1)
            elif char == '{':
                brace_depth += 1
            elif char == '}':
                brace_depth = max(0, brace_depth - 1)
            elif char == '[':
                bracket_depth += 1
            elif char == ']':
                bracket_depth = max(0, bracket_depth - 1)
            elif char == ';' and paren_depth == 0 and brace_depth == 0 and bracket_depth == 0:
                return content[start_index:i]

            i += 1

        return content[start_index:]

    def _extract_carter_metadata(self, block: str, file_content: str) -> Dict[str, Any]:
        """Extract WithName/WithSummary/WithDescription metadata."""
        metadata: Dict[str, Any] = {}

        def _extract(pattern: str) -> Optional[str]:
            match = re.search(pattern, block)
            if match:
                return match.group(1).strip()
            return None

        metadata["summary"] = _extract(r'\.WithSummary\s*\(\s*@?"([^"]+)"\s*\)')
        metadata["description"] = _extract(r'\.WithDescription\s*\(\s*@?"([^"]+)"\s*\)')
        metadata["operation_id"] = _extract(r'\.WithName\s*\(\s*@?"([^"]+)"\s*\)')
        metadata["responses"] = self._extract_carter_responses(block, file_content)

        return metadata

    def _extract_carter_responses(self, block: str, file_content: str) -> List[APIResponse]:
        """Extract response metadata from .Produces/.ProducesProblem calls."""
        responses: List[APIResponse] = []
        pattern = re.compile(
            r'\.(Produces|ProducesProblem)(?:<(?P<type>[^>]+)>)?\s*\(\s*(?P<args>[^\)]*)\)',
            re.MULTILINE,
        )

        for match in pattern.finditer(block):
            args = match.group("args") or ""
            tokens = [token.strip() for token in args.split(",") if token.strip()]

            status_code = 200
            body_type: Optional[str] = match.group("type")
            description = "Successful response"

            if match.group(1) == "ProducesProblem":
                description = "Problem response"

            for token in tokens:
                if "StatusCodes" in token or token.isdigit():
                    digits = re.search(r'(\d+)', token)
                    if digits:
                        status_code = int(digits.group(1))
                elif token.startswith("typeof"):
                    inside = re.search(r'typeof\s*\(\s*([^)]+)\s*\)', token)
                    if inside:
                        body_type = inside.group(1).strip()

            schema = None
            if body_type and match.group(1) != "ProducesProblem":
                schema = self._csharp_type_to_schema(body_type, file_content)
            elif match.group(1) == "ProducesProblem":
                schema = {"type": "object"}

            responses.append(
                APIResponse(
                    status_code=status_code,
                    description=description,
                    schema=schema,
                )
            )

        return responses

    def _extract_lambda_parameters(self, block: str) -> List[Dict[str, str]]:
        """Extract lambda parameter definitions from a Carter route."""
        # Find the lambda expression - look for pattern: , async? (...) =>
        # This handles cases like: MapPost("/path", async (Type param) => ...)
        # We need to find the lambda parameters, not the MapPost method call
        lambda_pattern = r',\s*(?:async\s+)?\(([^\)]*)\)\s*=>'
        match = re.search(lambda_pattern, block)
        if not match:
            # Fallback: try to find any (...) => pattern at the end
            lambda_pattern = r'(?:async\s+)?\(([^\)]*)\)\s*=>'
            matches = list(re.finditer(lambda_pattern, block))
            if not matches:
                return []
            # Use the last match
            match = matches[-1]
        
        params_str = match.group(1).strip()
        
        if not params_str:
            return []

        parameters: List[Dict[str, str]] = []
        for raw_param in self._split_parameters(params_str):
            cleaned = raw_param.strip()
            if not cleaned or cleaned == "_":
                continue

            attributes = re.findall(r'\[([^\]]+)\]', cleaned)
            attribute = attributes[-1] if attributes else None
            cleaned = re.sub(r'\[[^\]]+\]\s*', '', cleaned).strip()
            cleaned = re.sub(r'\b(ref|out|in|var)\b', '', cleaned).strip()

            if not cleaned:
                continue

            tokens = cleaned.rsplit(" ", 1)
            if len(tokens) != 2:
                continue

            param_type = tokens[0].strip()
            param_name = tokens[1].strip()
            
            # Clean up any stray parentheses or async keywords from type
            param_type = re.sub(r'^[\s\(]+', '', param_type)  # Remove leading spaces and parentheses
            param_type = re.sub(r'[\s\)]+$', '', param_type)  # Remove trailing spaces and parentheses
            param_type = re.sub(r'^\s*async\s+', '', param_type, flags=re.IGNORECASE)
            param_type = param_type.strip()
            
            # Clean up parameter name
            param_name = re.sub(r'^[\s\(]+', '', param_name)
            param_name = re.sub(r'[\s\)]+$', '', param_name)
            param_name = param_name.strip()

            parameters.append(
                {
                    "type": param_type,
                    "name": param_name,
                    "attribute": attribute,
                }
            )

        return parameters

    def _split_parameters(self, params: str) -> List[str]:
        """Split comma-separated parameter lists safely handling generics."""
        # Strip leading/trailing parentheses from the entire params string
        params = params.strip().lstrip('(').rstrip(')').strip()
        
        parts: List[str] = []
        current: List[str] = []
        depth = 0

        for char in params:
            if char == ',' and depth == 0:
                part = ''.join(current).strip()
                if part:
                    parts.append(part)
                current = []
                continue

            current.append(char)
            if char == '<':
                depth += 1
            elif char == '>':
                depth = max(0, depth - 1)

        if current:
            part = ''.join(current).strip()
            if part:
                parts.append(part)

        return parts

    def _classify_lambda_parameters(
        self,
        lambda_params: List[Dict[str, str]],
        path: str,
        file_content: str,
        existing_parameters: List[APIParameter],
    ) -> Tuple[List[APIParameter], Optional[Dict[str, Any]]]:
        """Classify lambda parameters into query/path/body buckets."""
        additional_params: List[APIParameter] = []
        request_body: Optional[Dict[str, Any]] = None
        path_vars = set(self.extract_path_variables(path))
        existing_map = {param.name: param for param in existing_parameters}

        for param in lambda_params:
            param_type = param.get("type", "").strip()
            param_name = param.get("name", "").strip()
            attribute = (param.get("attribute") or "").split('.')[-1]

            if not param_type or not param_name:
                continue

            base_type = self._normalize_type_name(param_type)
            if self._is_service_parameter(base_type):
                continue

            if param_name in path_vars:
                updated_type = self._csharp_type_to_openapi_type(param_type)
                if param_name in existing_map:
                    existing_map[param_name].type = updated_type
                else:
                    additional_params.append(
                        APIParameter(
                            name=param_name,
                            location=ParameterLocation.PATH,
                            required=True,
                            type=updated_type,
                        )
                    )
                continue

            if attribute.lower() == "fromheader":
                additional_params.append(
                    APIParameter(
                        name=param_name,
                        location=ParameterLocation.HEADER,
                        required=False,
                        type=self._csharp_type_to_openapi_type(param_type),
                    )
                )
                continue

            if attribute.lower() == "fromquery":
                additional_params.append(
                    APIParameter(
                        name=param_name,
                        location=ParameterLocation.QUERY,
                        required=False,
                        type=self._csharp_type_to_openapi_type(param_type),
                    )
                )
                continue

            should_use_body = (
                attribute.lower() == "frombody"
                or not self._is_simple_type(base_type)
            )

            if should_use_body:
                if not request_body:
                    request_body = self._build_request_body(param_type, file_content)
                continue

            additional_params.append(
                APIParameter(
                    name=param_name,
                    location=ParameterLocation.QUERY,
                    required=False,
                    type=self._csharp_type_to_openapi_type(param_type),
                )
            )

        return additional_params, request_body

    def _build_request_body(self, type_name: str, file_content: str) -> Dict[str, Any]:
        """Create a request body schema for the supplied type."""
        schema = self._csharp_type_to_schema(type_name, file_content)
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": schema,
                }
            },
        }

    def _is_service_parameter(self, type_name: str) -> bool:
        """Best-effort detection of DI-provided service parameters."""
        base = self._normalize_type_name(type_name)
        if base in self.SERVICE_TYPES:
            return True
        if base.startswith("ILogger"):
            return True
        if base.endswith("Service") or base.endswith("Repository"):
            return True
        if base.startswith("I") and len(base) > 1 and base[1].isupper() and base.endswith("Client"):
            return True
        return False

    def _is_simple_type(self, type_name: str) -> bool:
        """Check if a type is a simple scalar."""
        base = self._normalize_type_name(type_name)
        return base in self.SIMPLE_TYPES

    def _normalize_type_name(self, type_name: str) -> str:
        """Normalize C# type names by stripping namespaces, generics, and nullable markers."""
        if not type_name:
            return ""

        cleaned = type_name.strip()
        cleaned = cleaned.replace("?", "")
        cleaned = cleaned.replace("global::", "")

        if cleaned.endswith("[]"):
            cleaned = cleaned[:-2]

        if "<" in cleaned:
            cleaned = cleaned.split("<", 1)[0]

        if "." in cleaned:
            cleaned = cleaned.split(".")[-1]

        return cleaned.strip()

    def _split_generic_arguments(self, generic_args: str) -> List[str]:
        """Split generic arguments while handling nested generics."""
        parts: List[str] = []
        current: List[str] = []
        depth = 0

        for char in generic_args:
            if char == ',' and depth == 0:
                parts.append(''.join(current).strip())
                current = []
                continue

            current.append(char)
            if char == '<':
                depth += 1
            elif char == '>':
                depth = max(0, depth - 1)

        if current:
            parts.append(''.join(current).strip())

        return [part for part in parts if part]

    def _resolve_complex_type_schema(
        self,
        type_name: str,
        local_content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Resolve schema definitions for complex/DTO types."""
        normalized = self._normalize_type_name(type_name)
        if not normalized:
            return {"type": "object"}

        if normalized in self._type_schema_cache:
            return self._type_schema_cache[normalized]

        # Avoid recursive loops by caching placeholder first
        self._type_schema_cache[normalized] = {"type": "object"}

        schema: Optional[Dict[str, Any]] = None

        if local_content:
            schema = self._extract_schema_from_content(local_content, normalized)

        if not schema:
            for content in self._file_content_cache.values():
                schema = self._extract_schema_from_content(content, normalized)
                if schema:
                    break

        if not schema:
            schema = {"type": "object"}

        self._type_schema_cache[normalized] = schema
        return schema

    def _extract_schema_from_content(
        self,
        content: str,
        type_name: str,
    ) -> Optional[Dict[str, Any]]:
        """Extract schema information from record or class definitions."""
        if not content or type_name not in content:
            return None

        positional_pattern = re.compile(
            rf'record\s+{re.escape(type_name)}\s*\((?P<props>[^\)]*)\)',
            re.MULTILINE,
        )
        match = positional_pattern.search(content)
        if match:
            properties = self._parse_record_properties(match.group("props"), content)
            if properties:
                return {
                    "type": "object",
                    "properties": properties,
                    "required": list(properties.keys()),
                }

        # Try to find class/record with body
        class_pattern = re.compile(
            rf'(class|record)\s+{re.escape(type_name)}\s*[^{{]*\{{',
            re.MULTILINE,
        )
        match = class_pattern.search(content)
        if match:
            start_pos = match.end()
            # Extract body with proper brace matching
            brace_depth = 1
            i = start_pos
            n = len(content)
            body_end = start_pos
            
            while i < n and brace_depth > 0:
                if content[i] == '{':
                    brace_depth += 1
                elif content[i] == '}':
                    brace_depth -= 1
                    if brace_depth == 0:
                        body_end = i
                        break
                i += 1
            
            if body_end > start_pos:
                body = content[start_pos:body_end]
                property_pattern = re.compile(
                    r'\bpublic\s+([\w<>\.\[\]]+)\s+(\w+)\s*\{\s*get\s*[^}]*\}',
                    re.MULTILINE,
                )
                properties: Dict[str, Any] = {}
                required: List[str] = []

                for prop_match in property_pattern.finditer(body):
                    prop_type = prop_match.group(1).strip()
                    prop_name = prop_match.group(2).strip()
                    properties[prop_name] = self._csharp_type_to_schema(prop_type, content)
                    required.append(prop_name)

                if properties:
                    schema: Dict[str, Any] = {
                        "type": "object",
                        "properties": properties,
                    }
                    if required:
                        schema["required"] = required
                    return schema

        return None

    def _parse_record_properties(
        self,
        props: str,
        content: str,
    ) -> Dict[str, Any]:
        """Parse positional record constructor properties."""
        properties: Dict[str, Any] = {}

        for prop in self._split_parameters(props):
            cleaned = prop.strip()
            if not cleaned:
                continue

            tokens = cleaned.rsplit(" ", 1)
            if len(tokens) != 2:
                continue

            prop_type = tokens[0].strip()
            prop_name = tokens[1].strip()

            properties[prop_name] = self._csharp_type_to_schema(prop_type, content)

        return properties

    def _unwrap_known_wrappers(self, type_name: str) -> str:
        """Unwrap well-known generic wrappers like Task<T> or ActionResult<T>."""
        if not type_name:
            return type_name

        current = type_name.strip()
        wrappers = {"Task", "ValueTask", "ActionResult", "IActionResult"}

        while True:
            generic_match = re.match(r'([\w\.]+)<(.+)>', current)
            if not generic_match:
                break

            base = self._normalize_type_name(generic_match.group(1))
            if base not in wrappers:
                break

            args = self._split_generic_arguments(generic_match.group(2))
            if not args:
                break

            current = args[0].strip()

        return current

    def _create_path_parameters(self, path: str) -> List[APIParameter]:
        """Create path parameters from a normalized path."""
        parameters: List[APIParameter] = []
        for variable in self.extract_path_variables(path):
            parameters.append(
                APIParameter(
                    name=variable,
                    location=ParameterLocation.PATH,
                    required=True,
                    type="string",
                )
            )
        return parameters

    def _calculate_line_number(self, content: str, char_index: int) -> int:
        """Convert a character index to a 1-based line number."""
        return content.count("\n", 0, char_index) + 1

    def _combine_paths(self, base: str, path: str) -> str:
        """Combine base path and method path."""
        if not base:
            return path
        if not path:
            return base
        
        base = base.rstrip('/')
        path = path.lstrip('/')
        
        return f"{base}/{path}"

    def _resolve_action_token(self, path: str, signature: str) -> str:
        """Replace ``[action]`` with the method name (trailing ``Async`` stripped).

        Runtime token remapping via ``IOutboundParameterTransformer`` is out of scope.
        """
        if self._ACTION_TOKEN not in path:
            return path

        method_name = self._extract_method_name(signature)
        if not method_name:
            return path

        if method_name.endswith(self._ASYNC_SUFFIX) and method_name != self._ASYNC_SUFFIX:
            method_name = method_name[: -len(self._ASYNC_SUFFIX)]

        return path.replace(self._ACTION_TOKEN, method_name)

    def _extract_parameters(self, signature: str, path: str) -> List[APIParameter]:
        """Extract parameters from method signature."""
        parameters = []
        
        # Extract path parameters
        path_vars = self.extract_path_variables(path)
        for var in path_vars:
            # Try to find [FromRoute] annotation with type
            pattern = rf'\[FromRoute\]\s+([\w<>[\],\s]+)\s+{var}'
            match = re.search(pattern, signature)
            param_type = "string"
            if match:
                param_type = self._csharp_type_to_openapi_type(match.group(1).strip())
            
            parameters.append(
                APIParameter(
                    name=var,
                    location=ParameterLocation.PATH,
                    required=True,
                    type=param_type,
                )
            )
        
        # Extract [FromQuery] parameters with types
        pattern = r'\[FromQuery\](?:\([^)]*\))?\s+([\w<>[\],\s]+)\s+(\w+)'
        for match in re.finditer(pattern, signature):
            param_type = self._csharp_type_to_openapi_type(match.group(1).strip())
            param_name = match.group(2)
            if param_name not in path_vars:
                parameters.append(
                    APIParameter(
                        name=param_name,
                        location=ParameterLocation.QUERY,
                        required=False,
                        type=param_type,
                    )
                )
        
        # Extract [FromHeader] parameters
        pattern = r'\[FromHeader\](?:\([^)]*\))?\s+([\w<>[\],\s]+)\s+(\w+)'
        for match in re.finditer(pattern, signature):
            param_type = self._csharp_type_to_openapi_type(match.group(1).strip())
            param_name = match.group(2)
            parameters.append(
                APIParameter(
                    name=param_name,
                    location=ParameterLocation.HEADER,
                    required=False,
                    type=param_type,
                )
            )
        
        return parameters

    def _extract_request_body(
        self,
        signature: str,
        file_content: str,
    ) -> Optional[Dict[str, Any]]:
        """Extract request body from method signature."""
        if not signature:
            return None

        params_match = re.search(r'\((?P<params>[^\)]*)\)', signature)
        if not params_match:
            return None

        params_section = params_match.group("params")

        for param in self._split_parameters(params_section):
            cleaned = param.strip()
            if not cleaned:
                continue

            attributes = re.findall(r'\[([^\]]+)\]', cleaned)
            attribute = attributes[-1] if attributes else ""
            base = re.sub(r'\[[^\]]+\]\s*', '', cleaned).strip()

            tokens = base.rsplit(" ", 1)
            if len(tokens) != 2:
                continue

            param_type = tokens[0].strip()
            attr_lower = attribute.lower()

            if attr_lower == "frombody":
                return self._build_request_body(param_type, file_content)

            if attr_lower in {"fromroute", "fromquery", "fromheader"}:
                continue

            if self._is_service_parameter(param_type):
                continue

            if not self._is_simple_type(param_type):
                return self._build_request_body(param_type, file_content)

        return None

    def _extract_response_schema(
        self,
        signature: str,
        file_content: str,
    ) -> Optional[Dict[str, Any]]:
        """Extract response schema from method return type."""
        if not signature:
            return None

        pattern = r'\s*(?:public|private|protected|internal)?\s+([^\(\)]+?)\s+\w+\s*\('
        match = re.search(pattern, signature)
        if not match:
            return None

        return_type = match.group(1).strip()
        if not return_type or return_type.lower() in {"void"}:
            return None

        unwrapped = self._unwrap_known_wrappers(return_type)
        normalized = self._normalize_type_name(unwrapped)

        if normalized in {"void", "iresult", "actionresult", "iactionresult"}:
            return None

        return self._csharp_type_to_schema(unwrapped, file_content)

    def _csharp_type_to_openapi_type(self, csharp_type: str) -> str:
        """Convert C# type to OpenAPI type."""
        csharp_type = csharp_type.strip()
        type_map = {
            "int": "integer",
            "Int32": "integer",
            "long": "integer",
            "Int64": "integer",
            "float": "number",
            "Float": "number",
            "double": "number",
            "Double": "number",
            "decimal": "number",
            "Decimal": "number",
            "bool": "boolean",
            "Boolean": "boolean",
            "string": "string",
            "String": "string",
            "char": "string",
            "Char": "string",
            "Guid": "string",
            "DateTime": "string",
            "DateOnly": "string",
            "TimeOnly": "string",
        }
        return type_map.get(csharp_type, "string")

    def _csharp_type_to_schema(
        self,
        csharp_type: str,
        local_content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Convert C# type to OpenAPI schema."""
        if not csharp_type:
            return {"type": "object"}

        csharp_type = csharp_type.strip().replace("global::", "")

        if csharp_type.endswith("[]"):
            inner = csharp_type[:-2].strip()
            return {
                "type": "array",
                "items": self._csharp_type_to_schema(inner, local_content),
            }

        generic_match = re.match(r'([\w\.]+)<(.+)>', csharp_type)
        if generic_match:
            base = self._normalize_type_name(generic_match.group(1))
            args = self._split_generic_arguments(generic_match.group(2))

            if base in {"Task", "ValueTask"} and args:
                return self._csharp_type_to_schema(args[0], local_content)

            if base in {"List", "IList", "ICollection", "IEnumerable", "HashSet"} and args:
                return {
                    "type": "array",
                    "items": self._csharp_type_to_schema(args[0], local_content),
                }

            if base in {"Dictionary", "IDictionary"} and len(args) >= 2:
                return {
                    "type": "object",
                    "additionalProperties": self._csharp_type_to_schema(args[1], local_content),
                }

            if base in {"ActionResult", "IActionResult"} and args:
                return self._csharp_type_to_schema(args[0], local_content)

        if self._is_simple_type(csharp_type):
            return {"type": self._csharp_type_to_openapi_type(csharp_type)}

        return self._resolve_complex_type_schema(csharp_type, local_content)

    def _generate_operation_id(self, path: str, method: HTTPMethod) -> str:
        """Generate operation ID from path and method."""
        path_parts = [p for p in path.split('/') if p and not p.startswith('{')]
        operation_id = method.value.lower() + ''.join(p.capitalize() for p in path_parts)
        return operation_id

