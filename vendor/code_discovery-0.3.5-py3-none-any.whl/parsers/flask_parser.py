"""Flask parser."""

import ast
import re
from pathlib import Path
from typing import List, Optional, Dict, Any
from parsers.base import BaseParser
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


class FlaskParser(BaseParser):
    """Parser for Flask applications."""

    # Flasgger / Swagger template dict:  "title": "..."
    _FLASGGER_TITLE_RE = re.compile(r'"title"\s*:\s*"([^"]+)"')

    def parse(self) -> DiscoveryResult:
        """Parse Flask source files for API endpoints."""
        endpoints = []
        py_files = self.find_files("*.py")

        # Blueprint definition, ``register_blueprint(...)`` prefix and the route
        # decorator typically live in three different files; collect all three
        # before resolving any URL prefix.
        self._project_blueprints = self._collect_project_blueprints(py_files)

        for py_file in py_files:
            content = self.read_file(py_file)
            if content and self._has_flask_imports(content):
                endpoints.extend(self._parse_file(py_file, content))

        return DiscoveryResult(
            framework=FrameworkType.FLASK,
            endpoints=endpoints,
            title=self._extract_app_title(py_files),
        )

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.FLASK

    def _extract_app_title(self, py_files: List[Path]) -> Optional[str]:
        """Best-effort title from Flask-RESTX Api(..., title=...) or a Flasgger template dict."""
        for py_file in py_files:
            content = self.read_file(py_file)
            if not content:
                continue
            title = self._extract_restx_title_from_ast(content)
            if title:
                return title
            lower = content.lower()
            if "flasgger" in lower or "swagger" in lower:
                match = self._FLASGGER_TITLE_RE.search(content)
                if match:
                    return match.group(1).strip()
        return None

    @staticmethod
    def _extract_restx_title_from_ast(content: str) -> Optional[str]:
        """Parse AST for Api(..., title='...') — handles arbitrary arg expressions (e.g. nested calls)."""
        try:
            tree = ast.parse(content)
        except (SyntaxError, UnicodeDecodeError):
            return None
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            is_api_call = (
                (isinstance(func, ast.Name) and func.id == "Api")
                or (isinstance(func, ast.Attribute) and func.attr == "Api")
            )
            if not is_api_call:
                continue
            for kw in node.keywords:
                if kw.arg != "title":
                    continue
                if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                    return kw.value.value.strip() or None
        return None

    def _has_flask_imports(self, content: str) -> bool:
        """Check if file imports Flask."""
        return "from flask import" in content or "import flask" in content

    def _parse_file(self, file_path: Path, content: str) -> List[APIEndpoint]:
        """Parse a Python file for Flask endpoints."""
        endpoints = []
        
        try:
            tree = ast.parse(content)
            
            # Find blueprints and their prefixes
            blueprints = self._find_blueprints(tree, content)
            
            # Parse function decorators (sync and async views).
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    endpoints.extend(
                        self._parse_function(node, content, file_path, blueprints)
                    )
        except SyntaxError as e:
            print(f"Syntax error parsing {file_path}: {e}")
        
        return endpoints

    def _find_blueprints(self, tree: ast.AST, content: str) -> Dict[str, str]:
        """Per-file blueprint var -> ctor url_prefix (back-compat for tests)."""
        blueprints: Dict[str, str] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
                if hasattr(node.value.func, 'id') and node.value.func.id == 'Blueprint':
                    if node.targets and hasattr(node.targets[0], 'id'):
                        bp_var = node.targets[0].id
                        blueprints[bp_var] = self._extract_blueprint_prefix(node.value) or ""
        return blueprints

    def _collect_project_blueprints(self, py_files: List[Path]) -> Dict[str, Any]:
        """Project-wide blueprint index keyed by Blueprint(name) string.

        Returns ``defs`` (ctor info), ``register_prefixes`` (overrides ctor per
        Flask semantics), ``imports_per_file`` (alias resolution), and
        ``defs_by_var`` (cross-file lookup by the variable name used at the
        route decorator site).
        """
        defs: Dict[str, Dict[str, Any]] = {}
        register_prefixes: Dict[str, str] = {}
        imports_per_file: Dict[str, Dict[str, str]] = {}

        # Pass 1: collect Blueprint(...) definitions and import aliases.
        parsed: List[tuple] = []
        for f in py_files:
            content = self.read_file(f)
            if not content:
                continue
            try:
                tree = ast.parse(content)
            except SyntaxError:
                continue
            parsed.append((f, tree))

            file_aliases: Dict[str, str] = {}
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    for alias in node.names:
                        local = alias.asname or alias.name
                        file_aliases[local] = alias.name
                elif (
                    isinstance(node, ast.Assign)
                    and isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Name)
                    and node.value.func.id == 'Blueprint'
                    and node.targets
                    and isinstance(node.targets[0], ast.Name)
                ):
                    var = node.targets[0].id
                    bp_name = None
                    if node.value.args and isinstance(node.value.args[0], ast.Constant):
                        bp_name = node.value.args[0].value
                    if bp_name:
                        defs[bp_name] = {
                            "var": var,
                            "ctor_prefix": self._extract_blueprint_prefix(node.value) or "",
                            "file": str(f),
                        }
            imports_per_file[str(f)] = file_aliases

        # Pass 2: resolve register_blueprint(<var>, url_prefix=<prefix>).
        for f, tree in parsed:
            file_aliases = imports_per_file[str(f)]
            for node in ast.walk(tree):
                if not (
                    isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == 'register_blueprint'
                    and node.args
                    and isinstance(node.args[0], ast.Name)
                ):
                    continue
                local_name = node.args[0].id
                # Resolve through ``from X import bp as local_name``.
                target = file_aliases.get(local_name, local_name)
                bp_name = next(
                    (n for n, info in defs.items() if info["var"] == target),
                    None,
                )
                if not bp_name:
                    continue
                for kw in node.keywords:
                    if kw.arg == 'url_prefix' and isinstance(kw.value, ast.Constant):
                        if isinstance(kw.value.value, str):
                            register_prefixes[bp_name] = kw.value.value

        defs_by_var = {info["var"]: bp_name for bp_name, info in defs.items()}

        return {
            "defs": defs,
            "register_prefixes": register_prefixes,
            "imports_per_file": imports_per_file,
            "defs_by_var": defs_by_var,
        }

    def _resolve_route_prefix(self, bp_var: str, file_path: Path) -> str:
        """Resolve ``@<var>.route(...)`` to its URL prefix: import alias ->
        cross-project blueprint -> register_blueprint prefix (preferred over
        ctor, per Flask)."""
        data = getattr(self, "_project_blueprints", None) or {}
        defs = data.get("defs", {})
        defs_by_var = data.get("defs_by_var", {})
        register_prefixes = data.get("register_prefixes", {})
        aliases = data.get("imports_per_file", {}).get(str(file_path), {})

        candidate = aliases.get(bp_var, bp_var)
        bp_name = defs_by_var.get(candidate) or defs_by_var.get(bp_var)
        if not bp_name:
            return ""
        return register_prefixes.get(bp_name) or defs.get(bp_name, {}).get("ctor_prefix", "")

    def _extract_blueprint_prefix(self, call_node: ast.Call) -> Optional[str]:
        """Extract url_prefix from Blueprint call."""
        for keyword in call_node.keywords:
            if keyword.arg == 'url_prefix':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
        return None

    def _parse_function(
        self,
        func_node: ast.AST,
        content: str,
        file_path: Path,
        blueprints: Dict[str, str],
    ) -> List[APIEndpoint]:
        """Parse a function's decorators and return one endpoint per HTTP method."""
        endpoints: List[APIEndpoint] = []
        for decorator in func_node.decorator_list:
            endpoints.extend(
                self._parse_decorator(decorator, func_node, content, file_path, blueprints)
            )
        return endpoints

    def _parse_decorator(
        self,
        decorator: ast.AST,
        func_node: ast.AST,
        content: str,
        file_path: Path,
        blueprints: Dict[str, str],
    ) -> List[APIEndpoint]:
        """Emit one endpoint per HTTP method (multi-method routes need distinct ops)."""
        if not isinstance(decorator, ast.Call):
            return []
        if not (hasattr(decorator.func, 'attr') and decorator.func.attr == 'route'):
            return []

        path = self._extract_path_from_decorator(decorator)
        if not path:
            return []

        methods = self._extract_methods_from_decorator(decorator)
        if not methods:
            methods = [HTTPMethod.GET]

        obj_name = decorator.func.value.id if hasattr(decorator.func.value, 'id') else None
        prefix = ""
        if obj_name:
            prefix = self._resolve_route_prefix(obj_name, file_path)
            # Per-file fallback for tests / single-file inputs without register_blueprint.
            if not prefix and obj_name in blueprints:
                prefix = blueprints[obj_name]
        if prefix:
            path = prefix.rstrip('/') + path

        path = self.normalize_path(path)
        parameters = self._extract_parameters_from_function(func_node, path, content)
        response_schema = self._extract_response_schema(func_node, content)
        body_methods = {HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH}

        endpoints: List[APIEndpoint] = []
        for http_method in methods:
            request_body = (
                self._extract_request_body(func_node, content)
                if http_method in body_methods else None
            )
            endpoints.append(
                APIEndpoint(
                    path=path,
                    method=http_method,
                    summary=ast.get_docstring(func_node),
                    operation_id=func_node.name,
                    parameters=parameters,
                    request_body=request_body,
                    responses=[
                        APIResponse(
                            status_code=200,
                            description="Successful response",
                            schema=response_schema,
                        )
                    ],
                    source_file=self.get_relative_path(file_path),
                    source_line=func_node.lineno,
                )
            )
        return endpoints

    def _extract_path_from_decorator(self, decorator: ast.Call) -> Optional[str]:
        """Extract path from @route decorator."""
        # First positional argument
        if decorator.args:
            if isinstance(decorator.args[0], ast.Constant):
                return decorator.args[0].value
        
        # Keyword argument 'rule'
        for keyword in decorator.keywords:
            if keyword.arg == 'rule':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
        
        return None

    def _extract_methods_from_decorator(self, decorator: ast.Call) -> List[HTTPMethod]:
        """``methods=`` accepts list/tuple/set; without all three forms non-GET
        routes silently default to GET and collide on the same path."""
        methods: List[HTTPMethod] = []
        for keyword in decorator.keywords:
            if keyword.arg != 'methods':
                continue
            if isinstance(keyword.value, (ast.List, ast.Tuple, ast.Set)):
                for elt in keyword.value.elts:
                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                        try:
                            methods.append(HTTPMethod[elt.value.upper()])
                        except KeyError:
                            pass
        return methods

    def _extract_parameters_from_function(
        self,
        func_node: ast.FunctionDef,
        path: str,
        content: str,
    ) -> List[APIParameter]:
        """Extract parameters from function signature and path."""
        parameters = []
        
        # Extract path parameters
        path_vars = self.extract_path_variables(path)
        
        for var in path_vars:
            # Determine type from Flask path syntax
            param_type = "string"
            # Check for type converters in path: <int:id>, <float:id>, etc.
            if f"<int:{var}>" in path or f"<int:{var}/" in path:
                param_type = "integer"
            elif f"<float:{var}>" in path or f"<float:{var}/" in path:
                param_type = "number"
            
            parameters.append(
                APIParameter(
                    name=var,
                    location=ParameterLocation.PATH,
                    required=True,
                    type=param_type,
                )
            )
        
        # Extract function arguments that might be query parameters
        for arg in func_node.args.args:
            arg_name = arg.arg
            if arg_name in ['self', 'cls']:
                continue
            
            # If not a path variable, might be a query parameter
            if arg_name not in path_vars:
                # Check if it's used with request.args in function body
                is_query_param = self._is_query_parameter(arg_name, func_node, content)
                if is_query_param:
                    param_type = "string"
                    if arg.annotation:
                        param_type = self._extract_type_annotation(arg.annotation)
                    
                    required = self._is_parameter_required(arg, func_node)
                    
                    parameters.append(
                        APIParameter(
                            name=arg_name,
                            location=ParameterLocation.QUERY,
                            required=required,
                            type=param_type,
                        )
                    )
        
        return parameters

    def _is_query_parameter(
        self, param_name: str, func_node: ast.FunctionDef, content: str
    ) -> bool:
        """Check if parameter is used as query parameter (request.args)."""
        # Simple heuristic: check if request.args is used in function
        # In a more sophisticated implementation, we'd analyze the AST
        func_start = func_node.lineno
        func_end = func_node.end_lineno if hasattr(func_node, 'end_lineno') else func_start + 50
        
        lines = content.split('\n')
        func_lines = lines[func_start - 1 : func_end]
        func_content = '\n'.join(func_lines)
        
        # Check for request.args.get(param_name) or request.args[param_name]
        patterns = [
            rf'request\.args\.get\(["\']?{param_name}["\']?\)',
            rf'request\.args\[["\']?{param_name}["\']?\]',
        ]
        
        for pattern in patterns:
            if re.search(pattern, func_content):
                return True
        
        return False

    def _is_parameter_required(self, arg: ast.arg, func_node: ast.FunctionDef) -> bool:
        """Check if parameter is required (no default value)."""
        if not func_node.args.defaults:
            return True
        
        arg_index = func_node.args.args.index(arg)
        if func_node.args.args and func_node.args.args[0].arg in ['self', 'cls']:
            arg_index -= 1
        
        defaults_start = len(func_node.args.args) - len(func_node.args.defaults)
        return arg_index < defaults_start

    def _extract_type_annotation(self, annotation: ast.AST) -> str:
        """Extract type from annotation."""
        if isinstance(annotation, ast.Name):
            type_map = {
                'int': 'integer',
                'float': 'number',
                'bool': 'boolean',
                'str': 'string',
            }
            return type_map.get(annotation.id, 'string')
        return 'string'

    def _extract_request_body(
        self, func_node: ast.FunctionDef, content: str
    ) -> Optional[Dict[str, Any]]:
        """Extract request body from Flask function."""
        # Check for request.json or request.get_json() usage
        func_start = func_node.lineno
        func_end = func_node.end_lineno if hasattr(func_node, 'end_lineno') else func_start + 50
        
        lines = content.split('\n')
        func_lines = lines[func_start - 1 : func_end]
        func_content = '\n'.join(func_lines)
        
        # Check if function uses request.json or request.get_json()
        if re.search(r'request\.(json|get_json)', func_content):
            # Try to infer schema from function body or annotations
            # For now, return a generic object schema
            return {
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {"type": "object"},
                    }
                },
            }
        
        return None

    def _extract_response_schema(
        self, func_node: ast.FunctionDef, content: str
    ) -> Optional[Dict[str, Any]]:
        """Extract response schema from function return type."""
        if func_node.returns:
            return_type = self._extract_type_annotation(func_node.returns)
            if return_type == 'object':
                return {"type": "object"}
            elif return_type == 'array':
                return {"type": "array", "items": {"type": "object"}}
            else:
                return {"type": return_type}
        
        # Check if function returns jsonify() or dict
        func_start = func_node.lineno
        func_end = func_node.end_lineno if hasattr(func_node, 'end_lineno') else func_start + 50
        
        lines = content.split('\n')
        func_lines = lines[func_start - 1 : func_end]
        func_content = '\n'.join(func_lines)
        
        if 'jsonify' in func_content or 'return {' in func_content:
            return {"type": "object"}
        
        return None
