"""FastAPI parser."""

import ast
import re
from pathlib import Path
from typing import Dict, Any, FrozenSet, List, Optional, Set, Tuple
from parsers.base import BaseParser
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


class FastAPIParser(BaseParser):
    """Parser for FastAPI applications."""

    # Router identity is (defining_file, local_var_name).
    # Using a tuple key prevents collisions when multiple files all name their
    # router "router", which is the FastAPI-recommended canonical style.
    RouterId = Tuple[Path, str]

    # FastAPI parameter markers. Depends -> DI (skip), Body/Form/File -> request body,
    # the rest pin the parameter to an explicit OpenAPI ``in`` location.
    _DEPENDS_MARKER = "Depends"
    _BODY_MARKERS: FrozenSet[str] = frozenset({"Body", "Form", "File"})
    _LOCATION_MARKERS: Dict[str, ParameterLocation] = {
        "Query": ParameterLocation.QUERY,
        "Path": ParameterLocation.PATH,
        "Header": ParameterLocation.HEADER,
        "Cookie": ParameterLocation.COOKIE,
    }

    # SQLModel ships in a third-party package; treat its bare name as a Pydantic root
    # so project-defined SQLModel subclasses are recognised as request-body schemas.
    _PYDANTIC_ROOT_BASES: FrozenSet[str] = frozenset({"BaseModel", "SQLModel"})

    # FastAPI/Starlette runtime injection — never appears in the OpenAPI surface.
    _RUNTIME_INJECT_TYPES: FrozenSet[str] = frozenset({
        "Request", "Response", "BackgroundTasks",
        "WebSocket", "HTTPConnection", "UploadFile",
    })

    def __init__(self, source_paths: List[Path], repo_path: Path):
        super().__init__(source_paths, repo_path)
        self._file_content_cache: Dict[Path, str] = {}
        self._router_own_prefix: Dict[Tuple, str] = {}   # router_id -> its own prefix
        self._inclusions: List[Tuple] = []                # (parent_id, child_id, include_prefix)
        self._prefix_cache: Dict[Tuple, str] = {}         # memoized full prefixes
        self._model_schemas: Dict[str, Dict[str, Any]] = {}  # model_name -> schema
        # Transitive closure of Pydantic-rooted classes; populated cross-file in pass 1b
        # so chains like ``Article -> RWSchema -> RWModel -> BaseModel`` resolve.
        self._pydantic_class_names: Set[str] = set()
        # Module-level aliases ``T = Annotated[X, Depends(...)]`` so a bare-name
        # annotation (``session: SessionDep``) is recognised as DI.
        self._depends_aliases: Set[str] = set()

    def parse(self) -> DiscoveryResult:
        """Parse FastAPI source files for API endpoints."""
        endpoints = []
        py_files = self.find_files("*.py")
        
        _SKIP_DIRS = {'venv', '__pycache__', 'tests', 'test'}
        py_files = [
            f for f in py_files
            if not _SKIP_DIRS.intersection(f.parts)
        ]
        
        # Pass 1: cache content, then resolve cross-file Pydantic models and Depends aliases.
        for py_file in py_files:
            content = self.read_file(py_file)
            if content:
                self._file_content_cache[py_file] = content
        self._collect_pydantic_models()
        self._collect_depends_aliases()

        # Pass 2: register APIRouter definitions.
        for py_file, content in self._file_content_cache.items():
            if self._has_fastapi_imports(content):
                try:
                    self._find_router_definitions(py_file, content)
                except (SyntaxError, AttributeError):
                    continue

        # Pass 3: record include_router edges (parent->child prefix composition).
        for py_file, content in self._file_content_cache.items():
            if self._has_fastapi_imports(content):
                try:
                    self._process_include_router_calls(py_file, content)
                except (SyntaxError, AttributeError):
                    continue

        # Pass 4: parse endpoints with the prefix tree fully assembled.
        for py_file, content in self._file_content_cache.items():
            if self._has_fastapi_imports(content):
                endpoints.extend(self._parse_file(py_file, content))

        return DiscoveryResult(
            framework=FrameworkType.FASTAPI,
            endpoints=endpoints,
            title=self._extract_app_title(),
        )

    def get_framework_type(self) -> FrameworkType:
        return FrameworkType.FASTAPI

    def _extract_app_title(self) -> Optional[str]:
        """Return FastAPI(...) title= value from source, if present."""
        for content in self._file_content_cache.values():
            title = self._extract_fastapi_title_from_ast(content)
            if title:
                return title
        return None

    def _extract_fastapi_title_from_ast(self, content: str) -> Optional[str]:
        """Parse AST for FastAPI(title='...') / fastapi.FastAPI(title='...')."""
        try:
            tree = ast.parse(content)
        except (SyntaxError, UnicodeDecodeError):
            return None
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if not self._is_fastapi_constructor_call(node):
                continue
            for kw in node.keywords:
                if kw.arg != "title":
                    continue
                if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                    return kw.value.value.strip() or None
                if isinstance(kw.value, ast.Str):  # Python < 3.8
                    return (kw.value.s or "").strip() or None
        return None

    @staticmethod
    def _is_fastapi_constructor_call(node: ast.Call) -> bool:
        func = node.func
        if isinstance(func, ast.Name):
            return func.id == "FastAPI"
        if isinstance(func, ast.Attribute):
            return func.attr == "FastAPI"
        return False

    def _has_fastapi_imports(self, content: str) -> bool:
        return "from fastapi import" in content or "import fastapi" in content or "fastapi" in content.lower()

    def _find_router_definitions(self, file_path: Path, content: str):
        """Register every APIRouter definition with its own prefix (empty string when absent)."""
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Assign):
                    continue
                for target in node.targets:
                    if not isinstance(target, ast.Name):
                        continue
                    if not isinstance(node.value, ast.Call):
                        continue
                    if not self._is_apirouter_call(node.value):
                        continue
                    prefix = self._extract_router_prefix(node.value) or ""
                    self._router_own_prefix[(file_path, target.id)] = prefix
        except (SyntaxError, AttributeError):
            pass
    
    def _process_include_router_calls(self, file_path: Path, content: str):
        """Record every include_router call as a parent→child edge for later composition."""
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Expr):
                    continue
                call = node.value
                if not isinstance(call, ast.Call):
                    continue
                if not self._is_include_router_call(call, content):
                    continue

                child_arg = call.args[0] if call.args else None
                if child_arg is None:
                    continue

                child_id = self._resolve_router_id(child_arg, file_path, content)
                if child_id is None:
                    continue

                # Parent may be the FastAPI app itself (not an APIRouter).
                # If absent from _router_own_prefix the tree walk stops there — correct.
                parent_var = None
                if isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name):
                    parent_var = call.func.value.id
                parent_id: Tuple = (file_path, parent_var or "_app_")

                inc_prefix = self._extract_include_router_prefix(call) or ""
                self._inclusions.append((parent_id, child_id, inc_prefix))
        except (SyntaxError, AttributeError):
            pass

    def _resolve_router_id(
        self, arg: ast.AST, file_path: Path, content: str
    ) -> Optional[Tuple[Path, str]]:
        """Return the canonical (defining_file, var_name) identity of a router argument.

        Handles three patterns:
          - ``ast.Name``          → local variable, possibly an import alias
          - ``ast.Attribute``     → ``module.router`` (imported submodule)
        """
        if isinstance(arg, ast.Attribute) and isinstance(arg.value, ast.Name):
            source = self._find_import_source(arg.value.id, file_path, content)
            if source:
                return (source, arg.attr)
            return None

        if isinstance(arg, ast.Name):
            original, source = self._resolve_import_alias(arg.id, file_path, content)
            if source:
                return (source, original)
            return (file_path, arg.id)

        return None

    def _find_import_source(self, alias: str, file_path: Path, content: str) -> Optional[Path]:
        """Return the file that *alias* refers to as an imported module.

        Handles both patterns:
          - ``from app.api import authentication``  (ImportFrom — submodule)
          - ``import authentication``               (Import — direct module)
        """
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom) and node.module:
                    for name in node.names:
                        if (name.asname or name.name) == alias:
                            # Prefer `package.name` over `package` so that
                            # `from app.api import auth` resolves to app/api/auth.py.
                            resolved = self._resolve_module_path(
                                node.module + "." + name.name, file_path
                            )
                            if resolved:
                                return resolved
                            return self._resolve_module_path(node.module, file_path)
                elif isinstance(node, ast.Import):
                    for name in node.names:
                        if (name.asname or name.name) == alias:
                            return self._resolve_module_path(name.name, file_path)
        except Exception:
            pass
        return None

    def _resolve_import_alias(
        self, var_name: str, file_path: Path, content: str
    ) -> Tuple[str, Optional[Path]]:
        """If *var_name* came from an import statement, return (original_name, source_file).

        Handles both aliased and plain imports:
          - ``from users import router as users_router``  →  ("router", users.py)
          - ``from api import api_router``                →  ("api_router", api.py)
        """
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if not isinstance(node, ast.ImportFrom) or not node.module:
                    continue
                for alias in node.names:
                    local_name = alias.asname if alias.asname else alias.name
                    if local_name == var_name:
                        source = self._resolve_module_path(node.module, file_path)
                        if source:
                            return alias.name, source
        except Exception:
            pass
        return var_name, None

    def _resolve_full_prefix(
        self, router_id: Tuple, _visited: Optional[FrozenSet] = None
    ) -> str:
        """Walk the inclusion tree from *router_id* up to the app root and compose
        the full URL prefix.  Results are memoized; cycle-safe via *_visited*."""
        if router_id in self._prefix_cache:
            return self._prefix_cache[router_id]

        visited: FrozenSet = frozenset() if _visited is None else _visited
        if router_id in visited:
            return self._router_own_prefix.get(router_id, "")

        visited = visited | {router_id}
        own = self._router_own_prefix.get(router_id, "")

        parents = [
            (parent_id, inc_prefix)
            for parent_id, child_id, inc_prefix in self._inclusions
            if child_id == router_id
        ]

        if not parents:
            result = own
        else:
            if len(parents) > 1:
                print(
                    f"Warning: router '{router_id[1]}' is mounted under multiple "
                    f"parents; using the first mount for path composition."
                )
            parent_id, inc_prefix = parents[0]
            parent_full = self._resolve_full_prefix(parent_id, visited)
            result = parent_full + inc_prefix + own

        self._prefix_cache[router_id] = result
        return result

    def _is_apirouter_call(self, call_node: ast.Call) -> bool:
        if isinstance(call_node.func, ast.Name):
            return call_node.func.id == 'APIRouter'
        elif isinstance(call_node.func, ast.Attribute):
            return call_node.func.attr == 'APIRouter'
        return False

    def _is_include_router_call(self, call_node: ast.Call, content: str) -> bool:
        if isinstance(call_node.func, ast.Attribute):
            return call_node.func.attr == 'include_router'
        return False

    def _extract_router_prefix(self, call_node: ast.Call) -> Optional[str]:
        for keyword in call_node.keywords:
            if keyword.arg == 'prefix':
                return self._resolve_string_value(keyword.value)
        return None

    def _extract_include_router_prefix(self, call_node: ast.Call) -> Optional[str]:
        for keyword in call_node.keywords:
            if keyword.arg == 'prefix':
                return self._resolve_string_value(keyword.value)
        return None

    def _resolve_string_value(self, node: ast.AST) -> Optional[str]:
        """Resolve any AST node that could represent a string prefix.

        Handles every form a ``prefix=`` argument can take:

        * ``"/api/v1"``           — string literal
        * ``API_V1_STR``          — bare module-level or class-level constant
        * ``settings.API_V1_STR`` — attribute on any settings/config object
        """
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Str):  # Python < 3.8
            return node.s
        if isinstance(node, ast.Name):
            return self._find_string_constant(node.id)
        if isinstance(node, ast.Attribute):
            return self._find_string_constant(node.attr)
        return None

    def _find_string_constant(self, name: str) -> Optional[str]:
        """Search all cached files for a string-valued definition of *name*.

        Covers module-level plain assignments (``NAME = "/v1"``), module-level
        annotated assignments (``NAME: str = "/v1"``), and class-body equivalents
        — regardless of class name.  Returns the first match found.
        """
        for content in self._file_content_cache.values():
            try:
                result = self._find_string_in_source(name, content)
                if result is not None:
                    return result
            except (SyntaxError, AttributeError, UnicodeDecodeError):
                continue
        return None

    @staticmethod
    def _find_string_in_source(name: str, content: str) -> Optional[str]:
        """Return the string value of *name* if it is assigned a string literal
        anywhere in *content* (module level or inside a class body)."""
        try:
            tree = ast.parse(content)
        except (SyntaxError, UnicodeDecodeError):
            return None

        for node in ast.walk(tree):
            # Annotated assignment: name: str = "value"
            if isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name) and node.target.id == name and node.value:
                    val = node.value
                    if isinstance(val, ast.Constant) and isinstance(val.value, str):
                        return val.value
                    if isinstance(val, ast.Str):
                        return val.s
            # Plain assignment: name = "value"
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == name:
                        val = node.value
                        if isinstance(val, ast.Constant) and isinstance(val.value, str):
                            return val.value
                        if isinstance(val, ast.Str):
                            return val.s
        return None

    def _resolve_module_path(self, module: str, current_file: Path) -> Optional[Path]:
        """Resolve a dotted module string to the corresponding cached .py file."""
        if not module:
            return None

        parts = module.split('.')
        # Strip leading empty strings produced by relative-import dots.
        while parts and parts[0] == '':
            parts.pop(0)

        if not parts:
            return None

        current_dir = current_file.parent
        if module.startswith('.'):
            dot_count = len(module) - len(module.lstrip('.'))
            for _ in range(dot_count):
                current_dir = current_dir.parent

        file_path = current_dir
        for part in parts:
            file_path = file_path / part
        file_path = file_path.with_suffix('.py')

        if file_path in self._file_content_cache:
            return file_path

        package_init = file_path.with_suffix('') / '__init__.py'
        if package_init in self._file_content_cache:
            return package_init

        # Absolute or app-root-relative imports won't resolve via the relative path
        # above; fall back to a suffix match across all cached paths.
        suffix_parts = Path(*parts).with_suffix('.py').parts
        n = len(suffix_parts)
        for cached in self._file_content_cache:
            if cached.parts[-n:] == suffix_parts:
                return cached

        pkg_parts = tuple(parts) + ('__init__.py',)
        n = len(pkg_parts)
        for cached in self._file_content_cache:
            if cached.parts[-n:] == pkg_parts:
                return cached

        return None

    def _collect_pydantic_models(self) -> None:
        """Resolve every Pydantic-rooted class across files, then merge inherited fields.

        Two closures: first, transitive class membership (so ``Article -> RWSchema
        -> ... -> BaseModel`` is recognised); second, field inheritance (so
        ``class ItemCreate(ItemBase): pass`` inherits ItemBase's properties).
        """
        class_index: Dict[str, Tuple[ast.ClassDef, str]] = {}
        for content in self._file_content_cache.values():
            try:
                tree = ast.parse(content)
            except (SyntaxError, UnicodeDecodeError):
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef) and node.name not in class_index:
                    class_index[node.name] = (node, content)

        pydantic_names: Set[str] = set()
        for name, (node, _) in class_index.items():
            if self._has_pydantic_root_parent(node):
                pydantic_names.add(name)

        changed = True
        while changed:
            changed = False
            for name, (node, _) in class_index.items():
                if name in pydantic_names:
                    continue
                for base in node.bases:
                    base_name = base.id if isinstance(base, ast.Name) else (
                        base.attr if isinstance(base, ast.Attribute) else None
                    )
                    if base_name and base_name in pydantic_names:
                        pydantic_names.add(name)
                        changed = True
                        break

        self._pydantic_class_names = pydantic_names

        scaffolds: Dict[str, Dict[str, Any]] = {}
        for name in pydantic_names:
            node, source = class_index[name]
            own = self._extract_model_schema(node, source) or {}
            scaffolds[name] = {
                "properties": dict(own.get("properties") or {}),
                "required": list(own.get("required") or []),
                "bases": [
                    base.id if isinstance(base, ast.Name)
                    else base.attr if isinstance(base, ast.Attribute) else None
                    for base in node.bases
                ],
            }

        changed = True
        while changed:
            changed = False
            for scaf in scaffolds.values():
                for base_name in scaf["bases"]:
                    base_scaf = scaffolds.get(base_name)
                    if not base_scaf:
                        continue
                    for prop, val in base_scaf["properties"].items():
                        if prop not in scaf["properties"]:
                            scaf["properties"][prop] = val
                            changed = True
                    for req in base_scaf["required"]:
                        if req not in scaf["required"]:
                            scaf["required"].append(req)
                            changed = True

        for name, scaf in scaffolds.items():
            if not scaf["properties"]:
                continue
            schema: Dict[str, Any] = {"type": "object", "properties": scaf["properties"]}
            if scaf["required"]:
                schema["required"] = scaf["required"]
            self._model_schemas[name] = schema

    def _is_pydantic_model(self, class_node: ast.ClassDef) -> bool:
        if self._has_pydantic_root_parent(class_node):
            return True
        for base in class_node.bases:
            base_name = base.id if isinstance(base, ast.Name) else (
                base.attr if isinstance(base, ast.Attribute) else None
            )
            if base_name and base_name in self._pydantic_class_names:
                return True
        return False

    @classmethod
    def _has_pydantic_root_parent(cls, class_node: ast.ClassDef) -> bool:
        for base in class_node.bases:
            base_name = base.id if isinstance(base, ast.Name) else (
                base.attr if isinstance(base, ast.Attribute) else None
            )
            if base_name in cls._PYDANTIC_ROOT_BASES:
                return True
        return False

    def _collect_depends_aliases(self) -> None:
        """Register module-level ``T = Annotated[X, Depends(...)]`` alias names."""
        for content in self._file_content_cache.values():
            try:
                tree = ast.parse(content)
            except (SyntaxError, UnicodeDecodeError):
                continue
            for node in ast.iter_child_nodes(tree):
                if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Subscript):
                    continue
                outer = node.value.value
                is_annotated = (
                    (isinstance(outer, ast.Name) and outer.id == "Annotated")
                    or (isinstance(outer, ast.Attribute) and outer.attr == "Annotated")
                )
                if not is_annotated:
                    continue
                _, metadata = self._unwrap_annotated(node.value)
                has_depends = any(
                    isinstance(elt, ast.Call)
                    and self._call_func_name(elt) == self._DEPENDS_MARKER
                    for elt in metadata
                )
                if not has_depends:
                    continue
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        self._depends_aliases.add(target.id)

    def _extract_model_schema(self, class_node: ast.ClassDef, content: str) -> Optional[Dict[str, Any]]:
        properties = {}
        required = []
        field_types: Dict[str, str] = {}

        for item in class_node.body:
            if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                field_name = item.target.id
                field_types[field_name] = self._extract_type_annotation(item.annotation)

                is_required = True
                if item.value is not None:
                    if isinstance(item.value, ast.Constant):
                        is_required = False
                    elif isinstance(item.value, ast.Call):
                        is_required = self._is_field_call(item.value) and self._is_field_required(item.value)
                    elif isinstance(item.value, ast.Name):
                        is_required = False
                # item.value is None → no default → required

                if is_required:
                    required.append(field_name)
                properties[field_name] = self._extract_schema_type(item.annotation, content)

            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if not isinstance(target, ast.Name):
                        continue
                    field_name = target.id
                    field_type = field_types.get(field_name, "string")
                    if isinstance(item.value, ast.Call) and self._is_field_call(item.value):
                        if field_name in required:
                            required.remove(field_name)
                        field_schema = self._extract_field_schema(item.value, field_type, content)
                        if field_schema:
                            properties[field_name] = field_schema
                            continue
                    if field_name not in properties:
                        properties[field_name] = {"type": field_type}

        if not properties:
            return None
        schema: Dict[str, Any] = {"type": "object", "properties": properties}
        if required:
            schema["required"] = required
        return schema
    
    def _is_field_call(self, call_node: ast.Call) -> bool:
        if isinstance(call_node.func, ast.Name):
            return call_node.func.id == 'Field'
        elif isinstance(call_node.func, ast.Attribute):
            return call_node.func.attr == 'Field'
        return False

    def _is_field_required(self, field_call: ast.Call) -> bool:
        """Return True when Field() has no default.

        Pydantic uses ``Field(...)`` (Ellipsis) to mark a field as required.
        Any ``default=`` or ``default_factory=`` keyword means optional.
        """
        if field_call.args:
            first = field_call.args[0]
            if isinstance(first, (ast.Ellipsis,)):
                return True
            if isinstance(first, ast.Constant) and first.value is ...:
                return True
        for keyword in field_call.keywords:
            if keyword.arg in ('default', 'default_factory'):
                return False
        return True

    def _extract_field_schema(self, field_call: ast.Call, default_type: str, content: str) -> Optional[Dict[str, Any]]:
        # Could be enhanced to extract description, examples, constraints, etc.
        return {"type": default_type}
    
    def _extract_schema_type(self, annotation: ast.AST, content: str) -> Dict[str, Any]:
        """Recursively map a type annotation AST node to a JSON Schema fragment."""
        if isinstance(annotation, ast.Name):
            type_name = annotation.id
            if type_name in self._model_schemas:
                return self._model_schemas[type_name]
            type_map = {
                'int': 'integer', 'float': 'number', 'bool': 'boolean',
                'str': 'string', 'dict': 'object', 'list': 'array',
            }
            if type_name in type_map:
                return {"type": type_map[type_name]}
            for cached_content in self._file_content_cache.values():
                schema = self._find_pydantic_model_schema(type_name, cached_content)
                if schema and schema.get("properties"):
                    return schema
            return {"type": "object"}

        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name):
            outer = annotation.value.id
            if outer in ('List', 'list'):
                if hasattr(annotation, 'slice'):
                    item_type = self._extract_schema_type(annotation.slice, content)
                elif hasattr(annotation, 'elts'):  # Python < 3.9
                    item_type = self._extract_schema_type(annotation.elts[0], content)
                else:
                    item_type = {"type": "object"}
                return {"type": "array", "items": item_type}
            if outer == 'Optional':
                # Optional[T] — unwrap to T; None-ability is expressed via not required
                if hasattr(annotation, 'slice'):
                    return self._extract_schema_type(annotation.slice, content)
                if hasattr(annotation, 'elts'):  # Python < 3.9
                    return self._extract_schema_type(annotation.elts[0], content)
            if outer == 'Dict':
                return {"type": "object", "additionalProperties": True}

        return {"type": "object"}

    def _parse_file(self, file_path: Path, content: str) -> List[APIEndpoint]:
        endpoints = []
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    endpoint = self._parse_function(node, content, file_path)
                    if endpoint:
                        endpoints.append(endpoint)
        except SyntaxError as e:
            print(f"Syntax error parsing {file_path}: {e}")
        return endpoints

    def _parse_function(
        self,
        func_node: ast.AST,
        content: str,
        file_path: Path,
    ) -> Optional[APIEndpoint]:
        for decorator in func_node.decorator_list:
            endpoint = self._parse_decorator(decorator, func_node, content, file_path)
            if endpoint:
                return endpoint
        return None

    def _parse_decorator(
        self,
        decorator: ast.AST,
        func_node: ast.AST,
        content: str,
        file_path: Path,
    ) -> Optional[APIEndpoint]:
        if not isinstance(decorator, ast.Call) or not hasattr(decorator.func, 'attr'):
            return None

        method_name = decorator.func.attr.upper()
        if method_name not in ('GET', 'POST', 'PUT', 'DELETE', 'PATCH'):
            return None

        http_method = HTTPMethod[method_name]

        # None means no path arg at all — fall back to function name.
        # Empty string "" is a valid collection path and must not trigger the fallback.
        path = self._extract_path_from_decorator(decorator)
        if path is None:
            path = f"/{func_node.name}"

        router_name = None
        if hasattr(decorator.func, 'value'):
            if isinstance(decorator.func.value, ast.Name):
                router_name = decorator.func.value.id
            elif isinstance(decorator.func.value, ast.Attribute):
                router_name = decorator.func.value.attr

        if router_name:
            full_prefix = self._resolve_full_prefix((file_path, router_name))
            if full_prefix:
                path = full_prefix.rstrip('/') + '/' + path.lstrip('/')

        path = self.normalize_path(path)
        parameters = self._extract_parameters_from_function(func_node, path, content, file_path)
        request_body = self._extract_request_body(func_node, path, content, file_path)
        response_model = self._extract_response_model(decorator, func_node, content, file_path)
        status_code = self._extract_status_code(decorator)
        func_name = func_node.name if hasattr(func_node, 'name') else 'unknown'

        return APIEndpoint(
            path=path,
            method=http_method,
            summary=ast.get_docstring(func_node),
            operation_id=func_name,
            parameters=parameters,
            request_body=request_body,
            responses=[
                APIResponse(
                    status_code=status_code,
                    description="Successful response",
                    schema=response_model,
                )
            ],
            source_file=self.get_relative_path(file_path),
            source_line=func_node.lineno,
        )

    def _extract_status_code(self, decorator: ast.Call) -> int:
        for keyword in decorator.keywords:
            if keyword.arg == 'status_code':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
                if isinstance(keyword.value, ast.Attribute):
                    attr = keyword.value.attr  # e.g. HTTP_201_CREATED
                    if 'CREATED' in attr:
                        return 201
                    if 'OK' in attr:
                        return 200
        return 200

    def _extract_path_from_decorator(self, decorator: ast.Call) -> Optional[str]:
        if decorator.args:
            if isinstance(decorator.args[0], ast.Constant):
                return decorator.args[0].value
            if isinstance(decorator.args[0], ast.Str):  # Python < 3.8
                return decorator.args[0].s
        for keyword in decorator.keywords:
            if keyword.arg == 'path':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
                if isinstance(keyword.value, ast.Str):  # Python < 3.8
                    return keyword.value.s
        return None

    def _extract_response_model(
        self, decorator: ast.Call, func_node: ast.AST, content: str, file_path: Path
    ) -> Optional[Dict[str, Any]]:
        response_model_name = None
        for keyword in decorator.keywords:
            if keyword.arg == 'response_model':
                response_model_name = self._extract_type_name_from_ast(keyword.value)
        if not response_model_name and hasattr(func_node, 'returns') and func_node.returns:
            response_model_name = self._extract_type_name_from_ast(func_node.returns)
        if response_model_name:
            if response_model_name in self._model_schemas:
                return self._model_schemas[response_model_name]
            for cached_content in self._file_content_cache.values():
                schema = self._find_pydantic_model_schema(response_model_name, cached_content)
                if schema and schema.get("properties"):
                    return schema
        return None

    def _extract_type_name_from_ast(self, node: ast.AST) -> Optional[str]:
        if node is None:
            return None
        # Transparent unwrap: Annotated[T, ...] resolves to the type-name of T.
        if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "Annotated":
            inner, _ = self._unwrap_annotated(node)
            return self._extract_type_name_from_ast(inner)
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name):
            if node.value.id in ('List', 'Optional', 'Union'):
                if hasattr(node, 'slice'):
                    s = node.slice
                    if isinstance(s, ast.Name):
                        return s.id
                    if isinstance(s, ast.Index) and isinstance(s.value, ast.Name):  # Python < 3.9
                        return s.value.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    def _extract_parameters_from_function(
        self,
        func_node: ast.AST,
        path: str,
        content: str,
        file_path: Path,
    ) -> List[APIParameter]:
        """Classify each arg: Depends/body markers are dropped here; explicit
        location markers win; unmarked Pydantic types become bodies; everything
        else is a query param (FastAPI's default)."""
        parameters: List[APIParameter] = []
        if not hasattr(func_node, 'args'):
            return parameters

        path_vars = self.extract_path_variables(path)

        for arg, default in self._iter_function_args(func_node):
            classification = self._classify_arg_marker(arg, default)

            if classification == "depends":
                continue
            if classification == "body":
                continue

            type_node, _ = self._unwrap_annotated(arg.annotation) if arg.annotation else (None, [])
            type_name = self._extract_type_name_from_ast(type_node) if type_node is not None else None

            if arg.arg in path_vars:
                location = ParameterLocation.PATH
                required = True
            elif isinstance(classification, ParameterLocation):
                location = classification
                required = default is None
            else:
                if type_name in self._RUNTIME_INJECT_TYPES:
                    continue
                if self._annotation_resolves_to_pydantic(type_node):
                    continue
                location = ParameterLocation.QUERY
                required = default is None

            param_type = (
                self._extract_type_annotation(type_node) if type_node is not None else "string"
            )
            parameters.append(
                APIParameter(name=arg.arg, location=location, required=required, type=param_type)
            )

        return parameters

    @staticmethod
    def _iter_function_args(func_node: ast.AST):
        """Yield ``(arg_node, default_or_None)`` for positional and keyword-only args, skipping self/cls."""
        positional = list(getattr(func_node.args, 'args', []) or [])
        defaults = list(getattr(func_node.args, 'defaults', []) or [])
        offset = len(positional) - len(defaults)
        for index, arg in enumerate(positional):
            if arg.arg in ('self', 'cls'):
                continue
            default = defaults[index - offset] if index >= offset else None
            yield arg, default

        kwonly = list(getattr(func_node.args, 'kwonlyargs', []) or [])
        kw_defaults = list(getattr(func_node.args, 'kw_defaults', []) or [])
        for arg, default in zip(kwonly, kw_defaults):
            if arg.arg in ('self', 'cls'):
                continue
            yield arg, default

    def _classify_arg_marker(self, arg: ast.arg, default: Optional[ast.AST]):
        """Return ``"depends"`` | ``"body"`` | ``ParameterLocation`` | ``None``.

        Looks at the default value, ``Annotated[...]`` metadata, and module-level
        Depends aliases (in that order).
        """
        if isinstance(default, ast.Call):
            classification = self._classify_marker_call(default)
            if classification is not None:
                return classification

        if arg.annotation is not None:
            _, metadata = self._unwrap_annotated(arg.annotation)
            for node in metadata:
                if isinstance(node, ast.Call):
                    classification = self._classify_marker_call(node)
                    if classification is not None:
                        return classification

            if isinstance(arg.annotation, ast.Name) and arg.annotation.id in self._depends_aliases:
                return "depends"

        return None

    @classmethod
    def _classify_marker_call(cls, call: ast.Call):
        """Map ``Depends(...)`` / ``Body(...)`` / ``Query(...)`` etc. to a classifier verdict."""
        name = cls._call_func_name(call)
        if name is None:
            return None
        if name == cls._DEPENDS_MARKER:
            return "depends"
        if name in cls._BODY_MARKERS:
            return "body"
        if name in cls._LOCATION_MARKERS:
            return cls._LOCATION_MARKERS[name]
        return None

    @staticmethod
    def _call_func_name(call: ast.Call) -> Optional[str]:
        """Trailing identifier of a call: ``Depends`` / ``fastapi.Depends`` / aliased imports all collapse to the same name."""
        func = call.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            return func.attr
        return None

    @staticmethod
    def _unwrap_annotated(annotation: ast.AST) -> Tuple[ast.AST, List[ast.AST]]:
        """``Annotated[T, m1, m2]`` -> ``(T, [m1, m2])``; otherwise ``(annotation, [])``."""
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name):
            if annotation.value.id == "Annotated":
                slice_node = annotation.slice
                if hasattr(ast, "Index") and isinstance(slice_node, ast.Index):
                    slice_node = slice_node.value
                if isinstance(slice_node, ast.Tuple) and slice_node.elts:
                    return slice_node.elts[0], list(slice_node.elts[1:])
        return annotation, []

    def _annotation_resolves_to_pydantic(self, annotation: Optional[ast.AST]) -> bool:
        """True iff *annotation* is a known Pydantic class. Anything else
        (UUID, datetime, EmailStr, ...) falls through to FastAPI's default
        of treating it as a query parameter."""
        if annotation is None:
            return False
        type_name = self._extract_type_name_from_ast(annotation)
        if not type_name:
            return False
        return type_name in self._model_schemas or type_name in self._pydantic_class_names

    def _extract_request_body(
        self, func_node: ast.AST, path: str, content: str, file_path: Path
    ) -> Optional[Dict[str, Any]]:
        """First body-eligible arg's schema. Body candidates: explicit Body/Form/File
        markers, or unmarked Pydantic-typed args. Depends args are always skipped."""
        path_vars = self.extract_path_variables(path)
        if not hasattr(func_node, 'args'):
            return None

        for arg, default in self._iter_function_args(func_node):
            if arg.arg in path_vars or not arg.annotation:
                continue

            classification = self._classify_arg_marker(arg, default)
            if classification == "depends":
                continue
            if isinstance(classification, ParameterLocation):
                continue

            type_node, _ = self._unwrap_annotated(arg.annotation)
            type_name = self._extract_type_name_from_ast(type_node)
            if not type_name:
                continue
            if type_name in self._RUNTIME_INJECT_TYPES:
                continue
            schema = self._model_schemas.get(type_name)
            if not schema:
                for cached_content in self._file_content_cache.values():
                    schema = self._find_pydantic_model_schema(type_name, cached_content)
                    if schema and schema.get("properties"):
                        break
            if schema and schema.get("properties"):
                return {"required": True, "content": {"application/json": {"schema": schema}}}
        return None

    def _find_pydantic_model_schema(self, model_name: str, content: str) -> Optional[Dict[str, Any]]:
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef) and node.name == model_name:
                    if self._is_pydantic_model(node):
                        return self._extract_model_schema(node, content)
        except Exception:
            pass
        return None

    def _extract_type_annotation(self, annotation: ast.AST) -> str:
        if annotation is None:
            return 'string'
        # Annotated[T, ...] is reduced to T before the type-string mapping.
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name) and annotation.value.id == "Annotated":
            inner, _ = self._unwrap_annotated(annotation)
            return self._extract_type_annotation(inner)
        if isinstance(annotation, ast.Name):
            type_map = {
                'int': 'integer', 'float': 'number', 'bool': 'boolean',
                'str': 'string', 'dict': 'object', 'list': 'array',
            }
            return type_map.get(annotation.id, 'string')
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name):
            if annotation.value.id == 'List':
                return 'array'
            if annotation.value.id == 'Dict':
                return 'object'
        return 'string'
