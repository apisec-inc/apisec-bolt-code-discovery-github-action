"""Express.js API parser — regex-based, 4-pass strategy."""

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from parsers.base import BaseParser
from detectors.express_detector import is_node_source_file
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


# ---------------------------------------------------------------------------
# Compiled regex patterns
# ---------------------------------------------------------------------------

# Variable declarations
_APP_VAR_RE = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*=\s*'
    r'(?:require\s*\([\'"]express[\'"]\)\s*\(\s*\)|express\s*\(\s*\))'
)
_ROUTER_VAR_RE = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*=\s*'
    r'(?:express\.Router|Router|require\s*\([\'"]express[\'"]\)\.Router)\s*\(\s*\)'
)
_MODULE_EXPORTS_RE = re.compile(r'module\.exports\s*=\s*(\w+)')
_EXPORT_DEFAULT_RE = re.compile(r'export\s+default\s+(\w+)')

# Require / import
_REQUIRE_RE = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*=\s*require\s*\([\'"]([^\'"]+)[\'"]\)'
)
_IMPORT_DEFAULT_RE = re.compile(
    r'import\s+(\w+)\s+from\s+[\'"]([^\'"]+)[\'"]'
)

# Router mounting. Owner is not captured: the LHS may be an identifier
# (`app`, `router`) or a chained call expression (`Router()`, `).use(...)`).
_MOUNT_PREFIX_RE = re.compile(
    r'\.use\s*\(\s*[\'"](/[^\'"]*)[\'"]\s*,\s*(\w+)'
)
_MOUNT_BARE_RE = re.compile(
    r'\.use\s*\(\s*(\w+)\s*\)'
)

# Args of a single .use(...) call, parsed in isolation.
_USE_CALL_ARGS_RE = re.compile(
    r'^\s*(?:[\'"](/[^\'"]*)[\'"]\s*,\s*)?(\w+)\s*$'
)

# Route definitions. ``\s*`` between ``\w+`` and ``.`` allows the multi-line
# style ``router\n  .get(...)`` / ``router\n  .route('/')``.
_ROUTE_RE = re.compile(
    r'(\w+)\s*\.(get|post|put|delete|patch|head|options)\s*(?:<[^>]+>)?\s*\(\s*[\'"`]([^\'"` \n]+)[\'"`]',
    re.IGNORECASE,
)
_CHAINED_ROUTE_RE = re.compile(
    r'(\w+)\s*\.route\s*\(\s*[\'"`]([^\'"` \n]+)[\'"`]\s*\)'
)
_CHAINED_METHOD_RE = re.compile(
    r'\.(get|post|put|delete|patch|head|options)\s*\(',
    re.IGNORECASE,
)

# Handler body analysis
_QUERY_PARAM_RE = re.compile(r'req\.query\.(\w+)|req\.query\[[\'"](\w+)[\'"]\]')
_BODY_FIELD_RE = re.compile(r'req\.body\.(\w+)|req\.body\[[\'"](\w+)[\'"]\]')
_HEADER_PARAM_RE = re.compile(
    r'req\.(?:get|header)\s*\([\'"]([^\'"]+)[\'"]\)'
    r'|req\.headers\.(\w+)'
    r'|req\.headers\[[\'"](\w+)[\'"]\]'
)
_STATUS_RE = re.compile(r'res\.status\s*\(\s*(\d{3})\s*\)')

# JSDoc
_JSDOC_RE = re.compile(r'/\*\*([\s\S]*?)\*/', re.MULTILINE)
_JSDOC_SUMMARY_RE = re.compile(r'@summary\s+(.+)')
_JSDOC_DESC_RE = re.compile(r'@description\s+(.+)')
_JSDOC_PARAM_RE = re.compile(
    r'@param\s+\{(\w+)\}\s+(\w+)(?:\s+-\s*(.+))?'
)
_JSDOC_RETURNS_RE = re.compile(r'@returns?\s+(?:\{(\w+)\}\s+)?(.+)?')

# express-routes-mapper: 'METHOD /path': 'Controller.handler'
_ROUTES_MAPPER_REQUIRE_RE = re.compile(
    r'require\s*\([\'"]express-routes-mapper[\'"]\)'
)
_ROUTES_MAPPER_ENTRY_RE = re.compile(
    r'[\'"](?P<method>GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+(?P<path>/[^\'"]*)[\'"]',
    re.IGNORECASE,
)
# app.use('/prefix', mapRoutes(configVar, ...)) — capture the mount prefix
_ROUTES_MAPPER_MOUNT_RE = re.compile(
    r'\.use\s*\(\s*[\'"](?P<prefix>/[^\'"]*)[\'"]'
)

# HTTP method map
_METHOD_MAP: Dict[str, HTTPMethod] = {
    "get": HTTPMethod.GET,
    "post": HTTPMethod.POST,
    "put": HTTPMethod.PUT,
    "delete": HTTPMethod.DELETE,
    "patch": HTTPMethod.PATCH,
    "head": HTTPMethod.HEAD,
    "options": HTTPMethod.OPTIONS,
}

# Directories to exclude (re-exported from detector for use in this module)
_EXCLUDE_DIRS = {"node_modules", "dist", "build", ".git", "coverage", ".nyc_output"}  # kept for rglob filter

# Common app/router variable names — used as a fallback only when Pass 1 found
# no explicit express()/Router() declarations.  Kept narrow to avoid false
# positives (e.g. an axios instance named "api").
_COMMON_APP_NAMES = {"app", "router"}


class ExpressParser(BaseParser):
    """Parser for Express.js applications using a 4-pass regex strategy."""

    def __init__(self, source_paths: List[Path], repo_path: Path):
        super().__init__(source_paths, repo_path)
        # Pass 1 state
        self._file_content_cache: Dict[Path, str] = {}
        self._app_vars: Set[str] = set()
        self._router_vars: Set[str] = set()
        self._file_exports: Dict[Path, str] = {}  # file -> exported var name
        # Pass 2/3 state
        self._router_prefixes: Dict[str, str] = {}  # var name -> mounted prefix (global)
        self._file_router_prefixes: Dict[Tuple[Path, str], str] = {}  # (file, var) -> prefix
        self._var_source_file: Dict[str, Path] = {}  # var name -> file it was required from
        # child_var -> (parent_var, inline_prefix) from `Router().use(child)` chains.
        self._composition: Dict[str, Tuple[str, str]] = {}

    # ------------------------------------------------------------------
    # BaseParser interface
    # ------------------------------------------------------------------

    def get_framework_type(self) -> FrameworkType:
        """Return Express framework type."""
        return FrameworkType.EXPRESS

    def parse(self) -> DiscoveryResult:
        """Parse Express.js source for API endpoints using 4-pass strategy."""
        endpoints: List[APIEndpoint] = []

        # Gather all JS/TS source files
        js_ts_files = (
            self.find_files("*.js")
            + self.find_files("*.ts")
            + self.find_files("*.mjs")
        )
        js_ts_files = [f for f in js_ts_files if self._is_source_file(f)]

        if not js_ts_files:
            return DiscoveryResult(
                framework=FrameworkType.EXPRESS,
                endpoints=[],
                title="Express.js API",
            )

        # Pre-pass: detect express-routes-mapper config objects
        mapper_endpoints = self._prepass_routes_mapper(js_ts_files)
        if mapper_endpoints:
            endpoints.extend(mapper_endpoints)

        # Pass 1: Cache files and find variable declarations
        self._pass1_cache_and_find_vars(js_ts_files)

        # Pass 2: Resolve router mounts (app.use calls) within cached files
        self._pass2_resolve_router_mounts()

        # Pass 2b: Extract router-composition chains so parent prefixes flow
        # down to children mounted via `Router().use(child)` patterns.
        self._pass2b_extract_compositions()

        # Pass 3: Resolve cross-file routers (require/import chains)
        self._pass3_resolve_cross_file_routers()

        # Pass 4: Extract route definitions from all cached files
        for file_path, content in self._file_content_cache.items():
            try:
                file_endpoints = self._pass4_parse_routes(file_path, content)
                endpoints.extend(file_endpoints)
            except Exception as e:
                print(f"Warning: error parsing {file_path}: {e}")

        return DiscoveryResult(
            framework=FrameworkType.EXPRESS,
            endpoints=endpoints,
            title="Express.js API",
        )

    # ------------------------------------------------------------------
    # Pass 1: Cache files and discover variable names
    # ------------------------------------------------------------------

    def _pass1_cache_and_find_vars(self, files: List[Path]) -> None:
        """Cache all file contents and extract app/router variable declarations."""
        for file_path in files:
            content = self.read_file(file_path)
            if not content:
                continue
            self._file_content_cache[file_path] = content
            self._extract_var_declarations(file_path, content)

    def _extract_var_declarations(self, file_path: Path, content: str) -> None:
        """Find express() and express.Router() variable names in a file."""
        for m in _APP_VAR_RE.finditer(content):
            self._app_vars.add(m.group(1))

        for m in _ROUTER_VAR_RE.finditer(content):
            self._router_vars.add(m.group(1))

        # Track module.exports / export default so we know what each file exports
        exports_match = _MODULE_EXPORTS_RE.search(content)
        if exports_match:
            self._file_exports[file_path] = exports_match.group(1)
        else:
            esm_match = _EXPORT_DEFAULT_RE.search(content)
            if esm_match:
                self._file_exports[file_path] = esm_match.group(1)

    # ------------------------------------------------------------------
    # Pass 2: Resolve router mounts
    # ------------------------------------------------------------------

    def _pass2_resolve_router_mounts(self) -> None:
        """
        For every cached file, find app.use(prefix, router) or app.use(router)
        calls and build the _router_prefixes map.
        Also track which vars were loaded via require() for cross-file resolution.
        """
        for file_path, content in self._file_content_cache.items():
            # Build a local require map for this file
            local_require: Dict[str, Path] = {}
            for m in _REQUIRE_RE.finditer(content):
                var_name = m.group(1)
                req_path = m.group(2)
                resolved = self._resolve_require_path(file_path, req_path)
                if resolved:
                    local_require[var_name] = resolved

            for m in _IMPORT_DEFAULT_RE.finditer(content):
                var_name = m.group(1)
                imp_path = m.group(2)
                resolved = self._resolve_require_path(file_path, imp_path)
                if resolved:
                    local_require[var_name] = resolved

            # <expr>.use('/prefix', routerVar)
            for m in _MOUNT_PREFIX_RE.finditer(content):
                prefix = m.group(1)
                router_var = m.group(2)

                if not prefix.startswith("/"):
                    prefix = "/" + prefix

                self._router_prefixes[router_var] = prefix
                if router_var in local_require:
                    self._var_source_file[router_var] = local_require[router_var]

            # <expr>.use(routerVar)
            for m in _MOUNT_BARE_RE.finditer(content):
                router_var = m.group(1)
                if router_var not in self._router_prefixes:
                    self._router_prefixes[router_var] = "/"
                if router_var in local_require:
                    self._var_source_file[router_var] = local_require[router_var]

    # ------------------------------------------------------------------
    # Pass 2b: Router composition (chain mounts on a Router() instance)
    # ------------------------------------------------------------------

    def _pass2b_extract_compositions(self) -> None:
        """Record router-composition links from ``const X = Router().use(...)``
        chains. Children inherit X's prefix via ``_resolve_full_prefix``.
        """
        for content in self._file_content_cache.values():
            for m in _ROUTER_VAR_RE.finditer(content):
                self._scan_use_chain(content, m.end(), m.group(1))

    def _scan_use_chain(
        self, content: str, start: int, parent_var: str
    ) -> None:
        """Walk consecutive ``.use(...)`` calls at ``start`` and record each
        child as composed into ``parent_var``."""
        pos = start
        end_window = min(len(content), start + 2000)
        while pos < end_window:
            while pos < end_window and content[pos].isspace():
                pos += 1
            if pos >= end_window or content[pos:pos + 4] != ".use":
                break
            paren_pos = pos + 4
            while paren_pos < end_window and content[paren_pos].isspace():
                paren_pos += 1
            if paren_pos >= end_window or content[paren_pos] != "(":
                break
            close_pos = self._match_paren(content, paren_pos)
            if close_pos == -1:
                break
            am = _USE_CALL_ARGS_RE.match(content[paren_pos + 1:close_pos])
            if am:
                # First chain wins — a child router is normally composed once.
                self._composition.setdefault(
                    am.group(2), (parent_var, am.group(1) or "")
                )
            pos = close_pos + 1

    @staticmethod
    def _match_paren(content: str, open_pos: int) -> int:
        """Return the matching ``)`` for ``content[open_pos] == '('``, or -1.
        Skips over string/template literals so quoted parens don't confuse depth.
        """
        depth = 0
        in_str = False
        str_ch = ""
        i = open_pos
        while i < len(content):
            ch = content[i]
            if in_str:
                if ch == "\\":
                    i += 2
                    continue
                if ch == str_ch:
                    in_str = False
            else:
                if ch in ("'", '"', "`"):
                    in_str = True
                    str_ch = ch
                elif ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        return i
            i += 1
        return -1

    def _resolve_full_prefix(self, var: str) -> str:
        """Walk the composition chain to the root and combine inline prefixes.
        Composition links beat the per-var ``_router_prefixes`` entry, so a
        child mounted via ``parent.use(child)`` inherits parent's prefix.
        """
        seen: Set[str] = set()
        chain: List[str] = []  # leaf-toward-root
        cursor = var
        while cursor not in seen:
            seen.add(cursor)
            link = self._composition.get(cursor)
            if link is None:
                break
            cursor, inline = link[0], link[1]
            chain.append(inline)
        full = self._router_prefixes.get(cursor, "")
        for segment in reversed(chain):
            if segment:
                full = self._combine_paths(full, segment)
        return full

    # ------------------------------------------------------------------
    # Pass 3: Cross-file router resolution
    # ------------------------------------------------------------------

    def _pass3_resolve_cross_file_routers(self) -> None:
        """
        For vars loaded via require/import that have been mounted with a prefix,
        find the exported var in the target file and apply the prefix to it
        so Pass 4 can look it up correctly.

        Two cases are handled:
        1. The exported var name differs from the local router var name — map the
           exported name so Pass 4 picks it up in the source file.
        2. The exported var IS the local router var (common with `export default router`)
           — the prefix must be written under that var name directly.
        """
        for router_var, source_file in self._var_source_file.items():
            prefix = self._resolve_full_prefix(router_var) or "/"
            if source_file not in self._file_exports:
                # No exports map entry — propagate prefix to all router vars
                # declared in that source file using per-file mapping
                if source_file in self._file_content_cache:
                    content = self._file_content_cache[source_file]
                    for m in _ROUTER_VAR_RE.finditer(content):
                        local_var = m.group(1)
                        self._file_router_prefixes[(source_file, local_var)] = prefix
                continue
            exported_var = self._file_exports[source_file]
            # Write prefix per-file so that when multiple files each export a
            # variable named 'router', they get independent prefixes in Pass 4.
            self._file_router_prefixes[(source_file, exported_var)] = prefix

    # ------------------------------------------------------------------
    # Pre-pass: express-routes-mapper config objects
    # ------------------------------------------------------------------

    def _prepass_routes_mapper(self, files: List[Path]) -> List[APIEndpoint]:
        """
        Detect repos using `express-routes-mapper` and parse their route config
        objects.  Pattern:
            const mapRoutes = require('express-routes-mapper');
            app.use('/prefix', mapRoutes(configVar, ...));
            const config = { 'POST /path': 'Controller.method', ... };
        We scan every JS/TS file for route-mapper config key patterns
        ('METHOD /path') and collect mount prefixes from app.use() calls
        in the same codebase.
        """
        endpoints: List[APIEndpoint] = []

        # First check whether this repo even uses express-routes-mapper
        # (only look at the files handed to us by source_paths)
        uses_mapper = False
        file_contents: Dict[Path, str] = {}
        for fp in files:
            content = self.read_file(fp)
            if not content:
                continue
            file_contents[fp] = content
            if _ROUTES_MAPPER_REQUIRE_RE.search(content):
                uses_mapper = True

        if not uses_mapper:
            return []

        # Expand scan to JS/TS files in repo when mapper is in use —
        # route config objects are often in config/ dirs outside source_paths.
        # Cap at depth 5 and 200 files to avoid scanning monorepo trees.
        all_repo_files: List[Path] = []
        for ext in ("*.js", "*.ts"):
            for fp in self.repo_path.rglob(ext):
                if not self._is_source_file(fp):
                    continue
                if len(fp.relative_to(self.repo_path).parts) > 5:
                    continue
                all_repo_files.append(fp)
                if len(all_repo_files) >= 200:
                    break
            if len(all_repo_files) >= 200:
                break
        for fp in all_repo_files:
            if fp not in file_contents:
                content = self.read_file(fp)
                if content:
                    file_contents[fp] = content

        # Collect mount prefixes used with mapRoutes (app.use('/prefix', mapRoutes(...)))
        # We grab all /prefix strings from .use() calls as candidate prefixes.
        mount_prefixes: List[str] = []
        for content in file_contents.values():
            for m in _ROUTES_MAPPER_MOUNT_RE.finditer(content):
                prefix = m.group("prefix").rstrip("/")
                if prefix not in mount_prefixes:
                    mount_prefixes.append(prefix)

        # Fallback: no explicit prefix found → use root
        if not mount_prefixes:
            mount_prefixes = [""]

        # Scan all files for route config entries 'METHOD /path'
        # Track seen (method, full_path) to deduplicate across prefix variants
        seen: Set[Tuple[str, str]] = set()
        for fp, content in file_contents.items():
            for m in _ROUTES_MAPPER_ENTRY_RE.finditer(content):
                method_str = m.group("method").lower()
                raw_path = m.group("path")
                http_method = _METHOD_MAP.get(method_str)
                if not http_method:
                    continue

                # Try each known mount prefix; use the first non-duplicate
                for prefix in mount_prefixes:
                    full_path = self.normalize_path(
                        self._combine_paths(prefix, raw_path)
                    )
                    key = (method_str, full_path)
                    if key in seen:
                        continue
                    seen.add(key)

                    path_var_names = self.extract_path_variables(full_path)
                    parameters = [
                        APIParameter(
                            name=var,
                            location=ParameterLocation.PATH,
                            required=True,
                            type="string",
                        )
                        for var in path_var_names
                    ]
                    endpoints.append(
                        APIEndpoint(
                            path=full_path,
                            method=http_method,
                            operation_id=self._make_operation_id(http_method, full_path),
                            parameters=parameters,
                            responses=[APIResponse(status_code=200, description="Successful response")],
                            source_file=self.get_relative_path(fp),
                        )
                    )
                    break  # only emit one prefix variant per route entry

        return endpoints

    # ------------------------------------------------------------------
    # Pass 4: Route extraction
    # ------------------------------------------------------------------

    def _pass4_parse_routes(
        self, file_path: Path, content: str
    ) -> List[APIEndpoint]:
        """Extract APIEndpoint objects from a single file."""
        endpoints: List[APIEndpoint] = []
        lines = content.splitlines()
        line_starts = self._build_line_start_index(content)

        # Standard routes: obj.method('/path', ...)
        for m in _ROUTE_RE.finditer(content):
            obj_var = m.group(1)
            method_str = m.group(2).lower()
            raw_path = m.group(3)

            if not self._is_known_route_var(obj_var):
                continue

            endpoint = self._build_endpoint(
                obj_var=obj_var,
                method_str=method_str,
                raw_path=raw_path,
                file_path=file_path,
                content=content,
                match_start=m.start(),
                match_end=m.end(),
                line_starts=line_starts,
            )
            if endpoint:
                endpoints.append(endpoint)

        # Chained routes: obj.route('/path').get(...).post(...)
        for m in _CHAINED_ROUTE_RE.finditer(content):
            obj_var = m.group(1)
            raw_path = m.group(2)

            if not self._is_known_route_var(obj_var):
                continue

            # Find all .get/.post/etc. after the .route() call.
            # Limit lookahead to 800 chars.  Break when a semicolon appears
            # at brace depth 0 in the text preceding the candidate method —
            # semicolons inside handler bodies (depth > 0) don't terminate
            # the chain.
            after_route = content[m.end(): m.end() + 800]
            for mm in _CHAINED_METHOD_RE.finditer(after_route):
                method_str = mm.group(1).lower()
                preceding = after_route[:mm.start()]
                if self._has_top_level_semicolon(preceding):
                    break
                endpoint = self._build_endpoint(
                    obj_var=obj_var,
                    method_str=method_str,
                    raw_path=raw_path,
                    file_path=file_path,
                    content=content,
                    match_start=m.start(),
                    match_end=m.end() + mm.end(),
                    line_starts=line_starts,
                )
                if endpoint:
                    endpoints.append(endpoint)

        return endpoints

    def _build_endpoint(
        self,
        obj_var: str,
        method_str: str,
        raw_path: str,
        file_path: Path,
        content: str,
        match_start: int,
        match_end: int,
        line_starts: List[int],
    ) -> Optional[APIEndpoint]:
        """Construct an APIEndpoint from matched route data."""
        http_method = _METHOD_MAP.get(method_str)
        if not http_method:
            return None

        # Per-file prefix (Pass 3) wins so files that each export `router`
        # keep independent mounts; otherwise resolve via composition chain.
        prefix = self._file_router_prefixes.get(
            (file_path, obj_var),
            self._resolve_full_prefix(obj_var),
        )
        full_path = self._combine_paths(prefix, raw_path)
        full_path = self.normalize_path(full_path)

        # Path parameters
        path_var_names = self.extract_path_variables(full_path)
        parameters: List[APIParameter] = [
            APIParameter(
                name=var,
                location=ParameterLocation.PATH,
                required=True,
                type="string",
            )
            for var in path_var_names
        ]

        # Handler body analysis
        handler_body = self._extract_handler_body(content, match_end)
        request_body: Optional[Dict[str, Any]] = None

        if handler_body:
            # Query params
            seen_query: Set[str] = set()
            for qm in _QUERY_PARAM_RE.finditer(handler_body):
                param_name = qm.group(1) or qm.group(2)
                if param_name and param_name not in seen_query:
                    seen_query.add(param_name)
                    parameters.append(
                        APIParameter(
                            name=param_name,
                            location=ParameterLocation.QUERY,
                            required=False,
                            type="string",
                        )
                    )

            # Header params
            seen_headers: Set[str] = set()
            for hm in _HEADER_PARAM_RE.finditer(handler_body):
                header_name = hm.group(1) or hm.group(2) or hm.group(3)
                if header_name and header_name not in seen_headers:
                    seen_headers.add(header_name)
                    parameters.append(
                        APIParameter(
                            name=header_name,
                            location=ParameterLocation.HEADER,
                            required=False,
                            type="string",
                        )
                    )

            # Request body (presence of req.body usage)
            if _BODY_FIELD_RE.search(handler_body):
                body_props: Dict[str, Any] = {}
                for bm in _BODY_FIELD_RE.finditer(handler_body):
                    field_name = bm.group(1) or bm.group(2)
                    if field_name:
                        body_props[field_name] = {"type": "string"}
                request_body = {
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "properties": body_props,
                            }
                        }
                    }
                }

            # Response status codes from res.status(NNN)
            status_codes: Set[int] = set()
            for sm in _STATUS_RE.finditer(handler_body):
                try:
                    status_codes.add(int(sm.group(1)))
                except ValueError:
                    pass
        else:
            status_codes = set()

        # Build response list
        if status_codes:
            responses = [
                APIResponse(
                    status_code=code,
                    description="Response" if code != 200 else "Successful response",
                )
                for code in sorted(status_codes)
            ]
        else:
            responses = [APIResponse(status_code=200, description="Successful response")]

        # JSDoc summary/description
        summary, description = self._extract_jsdoc_above(content, match_start)

        # Operation ID
        operation_id = self._make_operation_id(http_method, full_path)

        # Source line number
        source_line = self._char_pos_to_line(match_start, line_starts)

        return APIEndpoint(
            path=full_path,
            method=http_method,
            summary=summary,
            description=description,
            operation_id=operation_id,
            parameters=parameters,
            request_body=request_body,
            responses=responses,
            source_file=self.get_relative_path(file_path),
            source_line=source_line,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_source_file(self, path: Path) -> bool:
        """Return False for generated/vendored files."""
        return is_node_source_file(path)

    def _is_known_route_var(self, var_name: str) -> bool:
        """
        Return True if var_name is a known app/router variable.
        Falls back to common convention names only when Pass 1 found no
        explicit declarations — avoids treating unrelated objects (e.g.
        an axios client named 'api') as Express routers.
        """
        if var_name in self._app_vars or var_name in self._router_vars:
            return True
        # Fallback to common names only when no explicit vars were detected
        if not self._app_vars and not self._router_vars:
            return var_name in _COMMON_APP_NAMES
        # Even with explicit vars, 'app' and 'router' are always safe
        return var_name in _COMMON_APP_NAMES

    @staticmethod
    def _has_top_level_semicolon(text: str) -> bool:
        """Return True if text contains a semicolon at brace depth 0."""
        depth = 0
        for ch in text:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
            elif ch == ";" and depth <= 0:
                return True
        return False

    def _resolve_require_path(
        self, current_file: Path, req_path: str
    ) -> Optional[Path]:
        """Resolve a require/import path relative to the current file."""
        if not req_path.startswith("."):
            return None  # External package, not cross-file
        base = current_file.parent
        candidate = base / req_path
        # Try exact path, then with .js / .ts extensions
        for suffix in ("", ".js", ".ts", "/index.js", "/index.ts"):
            resolved = Path(str(candidate) + suffix)
            if resolved.exists() and resolved.is_file():
                return resolved
        return None

    def _extract_handler_body(self, content: str, start: int) -> str:
        """
        Extract the body of the first handler function found after start
        using brace counting.  Scans up to 10 000 characters to handle
        large handler bodies while still bounding work.
        """
        window = content[start: start + 10000]
        # Find the first opening brace (start of a function body or arrow fn body)
        brace_pos = window.find("{")
        if brace_pos == -1:
            return ""

        depth = 0
        body_start = brace_pos
        i = brace_pos
        in_string = False
        string_char = ""

        while i < len(window):
            ch = window[i]
            if in_string:
                if ch == string_char and (i == 0 or window[i - 1] != "\\"):
                    in_string = False
            else:
                if ch in ('"', "'", "`"):
                    in_string = True
                    string_char = ch
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        return window[body_start + 1: i]
            i += 1

        return window[body_start + 1:]

    def _extract_jsdoc_above(
        self, content: str, match_start: int
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Look backward from match_start for a JSDoc comment /** ... */ and
        extract @summary / @description or first line as summary.
        Returns (summary, description).
        """
        preceding = content[:match_start]
        # Find the last JSDoc block before this position
        jsdoc_matches = list(_JSDOC_RE.finditer(preceding))
        if not jsdoc_matches:
            return None, None

        last_match = jsdoc_matches[-1]
        # Only use it if there's no code between the JSDoc and the route
        between = preceding[last_match.end():].strip()
        # Allow only whitespace, decorators, or empty lines
        if between and not re.match(r'^\s*$', between):
            return None, None

        doc_body = last_match.group(1)
        # Strip leading * from each line
        lines = [
            re.sub(r'^\s*\*\s?', '', line).strip()
            for line in doc_body.splitlines()
        ]
        lines = [l for l in lines if l]

        summary: Optional[str] = None
        description: Optional[str] = None

        sm = _JSDOC_SUMMARY_RE.search(doc_body)
        if sm:
            summary = sm.group(1).strip()

        dm = _JSDOC_DESC_RE.search(doc_body)
        if dm:
            description = dm.group(1).strip()

        # Fallback: use first non-tag line as summary
        if not summary and lines:
            first_content = next((l for l in lines if not l.startswith("@")), None)
            if first_content:
                summary = first_content

        return summary, description

    def _combine_paths(self, prefix: str, path: str) -> str:
        """Join prefix and path, avoiding double slashes."""
        prefix = prefix.rstrip("/")
        if not path.startswith("/"):
            path = "/" + path
        return prefix + path if prefix else path

    def _make_operation_id(self, method: HTTPMethod, path: str) -> str:
        """Generate a camelCase operation ID from HTTP method + path segments."""
        parts = [
            p.capitalize()
            for p in path.split("/")
            if p and not p.startswith("{")
        ]
        if parts:
            return method.value.lower() + "".join(parts)
        return method.value.lower() + "Endpoint"

    def _build_line_start_index(self, content: str) -> List[int]:
        """Build a list of character offsets where each line starts."""
        starts = [0]
        for i, ch in enumerate(content):
            if ch == "\n":
                starts.append(i + 1)
        return starts

    def _char_pos_to_line(self, pos: int, line_starts: List[int]) -> int:
        """Convert a character position to a 1-based line number."""
        lo, hi = 0, len(line_starts) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if line_starts[mid] <= pos:
                lo = mid
            else:
                hi = mid - 1
        return lo + 1
